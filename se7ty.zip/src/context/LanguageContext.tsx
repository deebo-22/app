import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { I18nManager } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import { ar, en, type TKey } from '@/src/i18n/strings';
import type { Language } from '@/src/types/database';

const STORAGE_KEY = 'se7ty.language';

interface LanguageState {
  language: Language;
  isRTL: boolean;
  t: (key: TKey, vars?: Record<string, string | number>) => string;
  /** Changes the UI language locally. Returns true if a restart is needed for native RTL. */
  setLanguage: (lang: Language) => Promise<boolean>;
}

const LanguageContext = createContext<LanguageState | null>(null);

I18nManager.allowRTL(true);

/**
 * Language handling:
 * - Our own screens get `direction: rtl|ltr` via <Screen>, so they flip instantly.
 * - Native chrome (tab bar order, navigation transitions) follows I18nManager,
 *   which only takes effect after an app restart — we set it and tell the user.
 * - Default is Arabic, matching profiles.preferred_language's default.
 */
export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLang] = useState<Language>('ar');

  useEffect(() => {
    SecureStore.getItemAsync(STORAGE_KEY)
      .then((v) => {
        if (v === 'ar' || v === 'en') setLang(v);
      })
      .catch(() => {});
  }, []);

  const setLanguage = useCallback(async (lang: Language) => {
    setLang(lang);
    await SecureStore.setItemAsync(STORAGE_KEY, lang).catch(() => {});
    const wantRTL = lang === 'ar';
    if (I18nManager.isRTL !== wantRTL) {
      I18nManager.forceRTL(wantRTL);
      return true;
    }
    return false;
  }, []);

  const value = useMemo<LanguageState>(() => {
    const dict = language === 'ar' ? ar : en;
    return {
      language,
      isRTL: language === 'ar',
      setLanguage,
      t: (key, vars) => {
        let s: string = dict[key] ?? en[key] ?? key;
        if (vars) for (const [k, v] of Object.entries(vars)) s = s.split(`{${k}}`).join(String(v));
        return s;
      },
    };
  }, [language, setLanguage]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useI18n() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useI18n must be used inside <LanguageProvider>');
  return ctx;
}
