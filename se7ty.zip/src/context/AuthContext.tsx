import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/src/services/supabase';
import { configurePurchases, resetPurchases } from '@/src/services/subscriptions';
import { setMonitoringUser, captureError } from '@/src/services/monitoring';
import { useI18n } from './LanguageContext';
import type { Language, Profile } from '@/src/types/database';

interface AuthState {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  /** True until the stored session has been read on startup. */
  isLoading: boolean;
  /**
   * Derived from the server-written profile row. Used for UI only — anything
   * that costs money or must be enforced (e.g. meal recognition) must re-check
   * the tier server-side.
   */
  isPro: boolean;
  refreshProfile: () => Promise<Profile | null>;
  signIn: (email: string, password: string) => Promise<void>;
  /** Returns true when a session was created immediately (email confirmation disabled). */
  signUp: (email: string, password: string, displayName: string) => Promise<boolean>;
  signOut: () => Promise<void>;
  updateProfile: (patch: { display_name?: string; preferred_language?: Language }) => Promise<void>;
}

const AuthContext = createContext<AuthState | null>(null);

export function computeIsPro(profile: Profile | null): boolean {
  if (!profile || profile.subscription_tier !== 'pro') return false;
  if (!profile.subscription_expires_at) return true;
  return new Date(profile.subscription_expires_at).getTime() > Date.now();
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const { language, setLanguage } = useI18n();
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const userId = session?.user.id ?? null;

  useEffect(() => {
    supabase.auth
      .getSession()
      .then(({ data }) => setSession(data.session))
      .catch(captureError)
      .finally(() => setIsLoading(false));

    const { data: sub } = supabase.auth.onAuthStateChange((_event, next) => {
      setSession(next);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const refreshProfile = useCallback(async () => {
    if (!userId) {
      setProfile(null);
      return null;
    }
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    if (error) {
      captureError(error);
      return null;
    }
    setProfile(data as Profile | null);
    return data as Profile | null;
  }, [userId]);

  // Load profile + wire third-party SDKs whenever the signed-in user changes.
  useEffect(() => {
    setMonitoringUser(userId);
    if (userId) {
      configurePurchases(userId);
      refreshProfile().then((p) => {
        if (p && p.preferred_language !== language) setLanguage(p.preferred_language);
      });
    } else {
      setProfile(null);
      resetPurchases();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  const signIn = useCallback(async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    if (error) throw error;
  }, []);

  const signUp = useCallback(
    async (email: string, password: string, displayName: string) => {
      const { data, error } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        // Read by the handle_new_user trigger (migration 0002) to create the profile row.
        options: { data: { display_name: displayName.trim(), preferred_language: language } },
      });
      if (error) throw error;
      return !!data.session;
    },
    [language],
  );

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
  }, []);

  const updateProfile = useCallback(
    async (patch: { display_name?: string; preferred_language?: Language }) => {
      if (!userId) return;
      // Only these two columns are client-writable (column grants in migration 0002).
      const { error } = await supabase.from('profiles').update(patch).eq('id', userId);
      if (error) throw error;
      await refreshProfile();
    },
    [userId, refreshProfile],
  );

  const value = useMemo<AuthState>(
    () => ({
      session,
      user: session?.user ?? null,
      profile,
      isLoading,
      isPro: computeIsPro(profile),
      refreshProfile,
      signIn,
      signUp,
      signOut,
      updateProfile,
    }),
    [session, profile, isLoading, refreshProfile, signIn, signUp, signOut, updateProfile],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
}
