/**
 * Se7ty design tokens.
 *
 * Sampled from the approved UI references (emerald primary, purple Pro accent,
 * cool light background, white bordered cards) and the app-icon logo (forest
 * green tile, cream wordmark, leaf-green "7"). Values are APPROXIMATE — pull
 * exact brand values from the logo/design source files before launch.
 */

export const colors = {
  background: '#F3F5F2',
  surface: '#FFFFFF',
  surfaceMuted: '#F1F3F1', // input fills, price box
  border: '#E2E7E3',
  divider: '#ECEFEC',

  primary: '#0B8A5C', // emerald — CTAs, active states
  primaryGradientEnd: '#0A6E4B',
  primaryPressed: '#087048',
  primarySoft: '#E3F5EC', // active nav pill, "Scan" chip in search
  primaryText: '#0B7A52',
  accentMint: '#7EE0B5', // scanner corners

  // Brand (logo) colors
  brandForest: '#173D2C',
  brandCream: '#F4EEE3',
  brandLeaf: '#7DB84F',

  pro: '#7C3AED', // purple — everything Pro/upsell
  proLight: '#8B5CF6',
  proSoft: '#EDE7FE',
  proText: '#6D28D9',

  text: '#101713',
  textBody: '#1F2723',
  textMuted: '#67716C',
  textSubtle: '#9AA39E',
  textOnPrimary: '#FFFFFF',
  textOnPrimaryMuted: 'rgba(255,255,255,0.88)',

  cameraBg: '#0B1F16',
  danger: '#DC2626',
  dark: '#111111', // "Look up" button

  /** Yuka-style judgment colors used by score dots, rings and nutrient rows. */
  judgment: {
    excellent: '#0F8F5B',
    good: '#4CC47A',
    poor: '#F59E0B',
    bad: '#EF4444',
    neutral: '#D5DBD7',
  },
  /** Verdict pills in lists ("● Excellent"). */
  pill: {
    excellent: { bg: '#DDF5E8', fg: '#0B7A4E' },
    good: { bg: '#E6F7EA', fg: '#2F8F4E' },
    poor: { bg: '#FEF3C7', fg: '#B45309' },
    bad: { bg: '#FEE2E2', fg: '#DC2626' },
  },
} as const;

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
} as const;

export const radius = {
  sm: 10,
  md: 14,
  lg: 18,
  xl: 24,
  pill: 999,
} as const;

export const font = {
  h1: { fontSize: 28, fontWeight: '800' as const, color: colors.text, letterSpacing: -0.5 },
  h2: { fontSize: 22, fontWeight: '700' as const, color: colors.text },
  h3: { fontSize: 18, fontWeight: '700' as const, color: colors.text },
  body: { fontSize: 15, fontWeight: '400' as const, color: colors.textBody },
  bodyMuted: { fontSize: 14, fontWeight: '400' as const, color: colors.textMuted },
  small: { fontSize: 12, fontWeight: '400' as const, color: colors.textMuted },
  label: { fontSize: 12, fontWeight: '700' as const, color: colors.textMuted, letterSpacing: 0.8 },
};

export const shadow = {
  card: {
    shadowColor: '#0B1F16',
    shadowOpacity: 0.05,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 2 },
    elevation: 1,
  },
} as const;
