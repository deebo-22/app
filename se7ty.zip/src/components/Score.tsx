import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import { colors } from '@/src/constants/theme';
import { useI18n } from '@/src/context/LanguageContext';
import type { Judgment } from '@/src/utils/scoring';

export function judgmentColor(j: Judgment | null | undefined) {
  return j ? colors.judgment[j] : colors.judgment.neutral;
}

export function ScoreDot({ judgment, size = 12 }: { judgment: Judgment | null; size?: number }) {
  return (
    <View
      style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: judgmentColor(judgment) }}
    />
  );
}

/** "● Excellent" pill used in list rows. */
export function VerdictPill({ verdict }: { verdict: Judgment }) {
  const { t } = useI18n();
  const c = colors.pill[verdict];
  return (
    <View style={[styles.pill, { backgroundColor: c.bg }]}>
      <View style={[styles.pillDot, { backgroundColor: c.fg }]} />
      <Text style={[styles.pillText, { color: c.fg }]}>{t(`verdict.${verdict}`)}</Text>
    </View>
  );
}

/** Circular progress ring. */
export function Ring({
  percent,
  size = 128,
  stroke = 9,
  color = colors.primary,
  track = colors.divider,
  children,
}: {
  percent: number;
  size?: number;
  stroke?: number;
  color?: string;
  track?: string;
  children?: React.ReactNode;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const clamped = Math.max(0, Math.min(100, percent));
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center', direction: 'ltr' }}>
      <Svg width={size} height={size} style={StyleSheet.absoluteFill}>
        <Circle cx={size / 2} cy={size / 2} r={r} stroke={track} strokeWidth={stroke} fill="none" />
        {clamped > 0 && (
          <Circle
            cx={size / 2}
            cy={size / 2}
            r={r}
            stroke={color}
            strokeWidth={stroke}
            fill="none"
            strokeLinecap="round"
            strokeDasharray={`${c} ${c}`}
            strokeDashoffset={c * (1 - clamped / 100)}
            transform={`rotate(-90 ${size / 2} ${size / 2})`}
          />
        )}
      </Svg>
      {children}
    </View>
  );
}

/** Small "82 / 100" ring used at the end of list rows. */
export function ScoreRing({ score, verdict, size = 46 }: { score: number | null; verdict: Judgment | null; size?: number }) {
  return (
    <Ring percent={score ?? 0} size={size} stroke={5} color={judgmentColor(verdict)} track={colors.divider}>
      <Text style={styles.ringScore}>{score ?? '—'}</Text>
      <Text style={styles.ringOf}>/ 100</Text>
    </Ring>
  );
}

/** Large header block on the product screen: ring + verdict. */
export function ScoreHeader({ score, verdict }: { score: number; verdict: Judgment }) {
  return (
    <View style={styles.headerRow}>
      <Ring percent={score} size={76} stroke={7} color={judgmentColor(verdict)}>
        <Text style={styles.headerScore}>{score}</Text>
        <Text style={styles.ringOf}>/ 100</Text>
      </Ring>
      <VerdictPill verdict={verdict} />
    </View>
  );
}

const styles = StyleSheet.create({
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    borderRadius: 999,
    paddingHorizontal: 9,
    paddingVertical: 3,
    alignSelf: 'flex-start',
  },
  pillDot: { width: 6, height: 6, borderRadius: 3 },
  pillText: { fontSize: 12, fontWeight: '700' },
  ringScore: { fontSize: 14, fontWeight: '800', color: colors.text, lineHeight: 16 },
  ringOf: { fontSize: 8, color: colors.textSubtle, lineHeight: 10 },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  headerScore: { fontSize: 24, fontWeight: '800', color: colors.text, lineHeight: 26 },
});
