import React, { useState } from 'react';
import { LayoutAnimation, Pressable, StyleSheet, Text, View } from 'react-native';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { colors, spacing } from '@/src/constants/theme';
import { useI18n } from '@/src/context/LanguageContext';
import type { TKey } from '@/src/i18n/strings';
import type { AdditiveRisk, ProductAdditive } from '@/src/types/database';
import type { NutrientAssessment } from '@/src/utils/scoring';
import { ScoreDot } from './Score';

const ICONS: Record<NutrientAssessment['key'], React.ComponentProps<typeof MaterialCommunityIcons>['name']> = {
  additives: 'molecule',
  sugar: 'cube-outline',
  saturates: 'water-outline',
  salt: 'shaker-outline',
  energy: 'fire',
  protein: 'fish',
  fiber: 'barley',
};

const RISK_COLOR: Record<AdditiveRisk, string> = {
  no_risk: colors.judgment.excellent,
  limited_risk: colors.judgment.poor,
  moderate_risk: '#F07F2E',
  high_risk: colors.judgment.bad,
};

function formatValue(a: NutrientAssessment, t: (k: TKey) => string) {
  if (a.key === 'additives') return String(a.value);
  const v = a.value >= 10 ? a.value.toFixed(0) : String(Math.round(a.value * 100) / 100);
  return `${v}${a.unit === 'kcal' ? ` ${t('common.kcal')}` : t('common.g')}`;
}

/** One Negatives/Positives row, expandable to show a scale bar or additive list. */
export function NutrientRow({
  assessment,
  additives,
  isLast,
}: {
  assessment: NutrientAssessment;
  additives?: ProductAdditive[];
  isLast?: boolean;
}) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const a = assessment;

  const subtitle =
    a.key === 'additives'
      ? t(`additive.${a.worstRisk ?? 'none'}` as TKey)
      : t(`nutrient.${a.key}.${a.judgment}` as TKey);

  const expandable = a.key === 'additives' ? (additives?.length ?? 0) > 0 : !!a.thresholds;

  return (
    <View>
      <Pressable
        onPress={() => {
          if (!expandable) return;
          LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
          setOpen((o) => !o);
        }}
        accessibilityRole="button"
        accessibilityState={{ expanded: open }}
        style={styles.row}
      >
        <MaterialCommunityIcons name={ICONS[a.key]} size={30} color={colors.textMuted} style={styles.icon} />
        <View style={[styles.body, !isLast && !open && styles.divider]}>
          <View style={{ flex: 1 }}>
            <Text style={styles.title}>{t(`nutrient.${a.key}` as TKey)}</Text>
            <Text style={styles.subtitle}>{subtitle}</Text>
          </View>
          <Text style={styles.value}>{formatValue(a, t)}</Text>
          <ScoreDot judgment={a.judgment} size={14} />
          <Feather
            name={open ? 'chevron-up' : 'chevron-down'}
            size={22}
            color={expandable ? colors.textMuted : 'transparent'}
          />
        </View>
      </Pressable>
      {open && (
        <View style={[styles.expanded, !isLast && styles.divider]}>
          {a.key === 'additives' ? (
            additives?.map((ad) => (
              <View key={ad.id} style={styles.additive}>
                <View style={[styles.riskDot, { backgroundColor: RISK_COLOR[ad.risk_level] }]} />
                <Text style={styles.additiveCode}>{ad.code}</Text>
                <Text style={styles.additiveName} numberOfLines={1}>
                  {ad.name}
                </Text>
                <Text style={styles.additiveRisk}>{t(`risk.${ad.risk_level}`)}</Text>
              </View>
            ))
          ) : (
            <ScaleBar assessment={a} />
          )}
        </View>
      )}
    </View>
  );
}

/** Four-color scale with the product's position marked, like Yuka's expanded rows. */
function ScaleBar({ assessment }: { assessment: NutrientAssessment }) {
  const t = assessment.thresholds ?? [];
  const segments = assessment.higherIsBetter
    ? [colors.judgment.neutral, colors.judgment.good, colors.judgment.excellent]
    : [colors.judgment.excellent, colors.judgment.good, colors.judgment.poor, colors.judgment.bad];
  const max = (t[t.length - 1] ?? 1) * 1.5;
  const pos = Math.min(1, assessment.value / max);
  return (
    <View style={{ paddingVertical: spacing.sm, direction: 'ltr' }}>
      <View style={styles.scale}>
        {segments.map((c, i) => {
          const start = i === 0 ? 0 : t[i - 1] / max;
          const end = i < t.length ? t[i] / max : 1;
          return <View key={i} style={{ flex: Math.max(end - start, 0.01), backgroundColor: c }} />;
        })}
      </View>
      <View style={[styles.marker, { left: `${pos * 100}%` }]} />
      <View style={styles.scaleLabels}>
        {t.map((v, i) => (
          <Text key={i} style={[styles.scaleLabel, { left: `${(v / max) * 100}%` }]}>
            {v}
          </Text>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center' },
  icon: { width: 48 },
  body: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingVertical: spacing.lg,
  },
  divider: { borderBottomWidth: 1, borderBottomColor: colors.divider },
  title: { fontSize: 18, color: colors.textBody },
  subtitle: { fontSize: 15, color: colors.textMuted, marginTop: 2 },
  value: { fontSize: 16, color: colors.textMuted },
  expanded: { marginStart: 48, paddingBottom: spacing.lg },
  scale: { flexDirection: 'row', height: 8, borderRadius: 4, overflow: 'hidden' },
  marker: {
    position: 'absolute',
    top: 2,
    width: 4,
    height: 20,
    marginLeft: -2,
    borderRadius: 2,
    backgroundColor: colors.textBody,
  },
  scaleLabels: { height: 18, marginTop: 6 },
  scaleLabel: { position: 'absolute', fontSize: 11, color: colors.textMuted, marginLeft: -8 },
  additive: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingVertical: 6 },
  riskDot: { width: 10, height: 10, borderRadius: 5 },
  additiveCode: { fontSize: 14, fontWeight: '600', color: colors.textBody, minWidth: 52 },
  additiveName: { flex: 1, fontSize: 14, color: colors.textBody },
  additiveRisk: { fontSize: 12, color: colors.textMuted },
});
