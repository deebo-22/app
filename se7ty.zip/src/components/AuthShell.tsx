import React from 'react';
import { KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, font, radius, spacing } from '@/src/constants/theme';
import { isSupabaseConfigured } from '@/src/constants/env';
import { useI18n } from '@/src/context/LanguageContext';
import { Screen } from './Screen';
import { BrandTile } from './Logo';

/** Shared chrome for sign-in / sign-up: logo tile, tagline, language switch, title. */
export function AuthShell({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  const { t, language, setLanguage } = useI18n();
  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Screen contentStyle={styles.content}>
        <View style={styles.langRow}>
          <Pressable
            onPress={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
            accessibilityRole="button"
            style={styles.langButton}
          >
            <Text style={styles.langText}>{language === 'ar' ? 'English' : 'العربية'}</Text>
          </Pressable>
        </View>
        <View style={styles.brand}>
          <BrandTile size={128} />
          <Text style={styles.tagline}>{t('brand.tagline')}</Text>
        </View>
        <View style={styles.card}>
          <Text style={font.h2}>{title}</Text>
          <Text style={[font.bodyMuted, { marginTop: 4, marginBottom: spacing.lg }]}>{subtitle}</Text>
          {!isSupabaseConfigured && (
            <View style={styles.warning}>
              <Text style={styles.warningText}>{t('common.notConfigured')}</Text>
            </View>
          )}
          <View style={{ gap: spacing.md }}>{children}</View>
        </View>
      </Screen>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: spacing.lg },
  langRow: { flexDirection: 'row', justifyContent: 'flex-end' },
  langButton: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderRadius: radius.pill,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
  },
  langText: { fontSize: 13, fontWeight: '700', color: colors.text },
  brand: { alignItems: 'center', marginTop: spacing.xxl, marginBottom: spacing.xxl, gap: spacing.md },
  tagline: { fontSize: 15, color: colors.textMuted },
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.xl,
  },
  warning: {
    backgroundColor: '#FFF4E0',
    borderRadius: 12,
    padding: spacing.md,
    marginBottom: spacing.lg,
  },
  warningText: { color: '#8A5A00', fontSize: 13 },
});
