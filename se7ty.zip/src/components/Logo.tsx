import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Svg, { Path } from 'react-native-svg';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '@/src/constants/theme';

/**
 * Vector re-creation of the Se7ty logo (two leaves over a cream "Se7ty" with a
 * leaf-green "7"). Replace with the real exported logo asset once available.
 * The wordmark is always laid out LTR, even in the Arabic UI.
 */

function Leaves({ width }: { width: number }) {
  const h = width * 0.55;
  return (
    <Svg width={width} height={h} viewBox="0 0 100 55">
      {/* left leaf */}
      <Path d="M48 52 C 30 50, 8 40, 4 14 C 26 12, 44 26, 48 52 Z" fill={colors.brandLeaf} />
      <Path d="M46 48 C 36 38, 24 28, 12 20" stroke={colors.brandForest} strokeWidth={2.5} fill="none" strokeLinecap="round" />
      {/* right leaf */}
      <Path d="M52 52 C 50 26, 66 6, 96 2 C 96 32, 76 50, 52 52 Z" fill={colors.brandLeaf} />
      <Path d="M54 48 C 64 34, 76 20, 88 10" stroke={colors.brandForest} strokeWidth={2.5} fill="none" strokeLinecap="round" />
    </Svg>
  );
}

/** Wordmark "Se7ty" with leaves above the 7. `onDark` = cream text on the forest tile. */
export function Wordmark({ size = 48, onDark = false }: { size?: number; onDark?: boolean }) {
  const base = onDark ? colors.brandCream : colors.brandForest;
  return (
    <View style={styles.wordWrap} accessibilityRole="header" accessibilityLabel="Se7ty">
      <View style={{ alignItems: 'center', marginBottom: -size * 0.12, marginLeft: size * 0.55 }}>
        <Leaves width={size * 0.95} />
      </View>
      <View style={styles.row}>
        <Text style={[styles.word, { fontSize: size, color: base }]}>Se</Text>
        <Text style={[styles.word, styles.seven, { fontSize: size, color: colors.brandLeaf }]}>7</Text>
        <Text style={[styles.word, { fontSize: size, color: base }]}>ty</Text>
      </View>
    </View>
  );
}

/** App-icon style tile: forest-green rounded square with the cream wordmark. */
export function BrandTile({ size = 132 }: { size?: number }) {
  return (
    <View
      style={[
        styles.tile,
        { width: size, height: size, borderRadius: size * 0.26 },
      ]}
    >
      <Wordmark size={size * 0.27} onDark />
    </View>
  );
}

/** Compact header logo from the UI reference: emerald rounded square + "Se7ty". */
export function HeaderLogo() {
  return (
    <View style={styles.header} accessibilityRole="header" accessibilityLabel="Se7ty">
      <View style={styles.mark}>
        <Ionicons name="leaf-outline" size={17} color="#fff" />
      </View>
      <Text style={styles.headerText}>Se7ty</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  wordWrap: { direction: 'ltr', alignItems: 'flex-start' },
  row: { flexDirection: 'row', alignItems: 'flex-end' },
  word: { fontWeight: '800', letterSpacing: -1 },
  seven: { transform: [{ skewX: '-8deg' }] },
  tile: {
    backgroundColor: colors.brandForest,
    alignItems: 'center',
    justifyContent: 'center',
  },
  header: { flexDirection: 'row', alignItems: 'center', gap: 8, direction: 'ltr' },
  mark: {
    width: 30,
    height: 30,
    borderRadius: 9,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerText: { fontSize: 19, fontWeight: '800', color: colors.text, letterSpacing: -0.3 },
});
