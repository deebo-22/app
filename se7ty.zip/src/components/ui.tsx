import React from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
  type StyleProp,
  type TextInputProps,
  type ViewStyle,
} from 'react-native';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { colors, font, radius, shadow, spacing } from '@/src/constants/theme';
import { useI18n } from '@/src/context/LanguageContext';
import { useAuth } from '@/src/context/AuthContext';
import { HeaderLogo } from './Logo';

/** Forward arrow/chevron that points the right way in both LTR and RTL. */
export function ForwardArrow({
  color = colors.textMuted,
  size = 20,
  chevron = true,
}: {
  color?: string;
  size?: number;
  chevron?: boolean;
}) {
  const { isRTL } = useI18n();
  const name = chevron ? (isRTL ? 'chevron-left' : 'chevron-right') : isRTL ? 'arrow-left' : 'arrow-right';
  return <Feather name={name} size={size} color={color} />;
}

export function BackChevron({ color = colors.text, size = 24 }: { color?: string; size?: number }) {
  const { isRTL } = useI18n();
  return <Feather name={isRTL ? 'chevron-right' : 'chevron-left'} size={size} color={color} />;
}

/** Top bar used on the tab screens: logo on one side, "Go Pro" on the other. */
export function AppHeader() {
  const { t } = useI18n();
  const { isPro } = useAuth();
  return (
    <View style={styles.appHeader}>
      <HeaderLogo />
      {isPro ? (
        <ProBadge label={t('common.pro')} locked={false} />
      ) : (
        <Pressable
          onPress={() => router.push('/paywall')}
          accessibilityRole="button"
          style={({ pressed }) => [styles.goPro, pressed && { opacity: 0.85 }]}
        >
          <MaterialCommunityIcons name="crown-outline" size={16} color="#fff" />
          <Text style={styles.goProText}>{t('common.goPro')}</Text>
        </Pressable>
      )}
    </View>
  );
}

export function CircleButton({
  onPress,
  children,
  label,
  style,
}: {
  onPress: () => void;
  children: React.ReactNode;
  label: string;
  style?: StyleProp<ViewStyle>;
}) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      hitSlop={8}
      style={({ pressed }) => [styles.circleButton, pressed && { opacity: 0.7 }, style]}
    >
      {children}
    </Pressable>
  );
}

type ButtonVariant = 'primary' | 'pro' | 'dark' | 'secondary' | 'ghost' | 'danger';

export function Button({
  title,
  onPress,
  variant = 'primary',
  loading,
  disabled,
  icon,
  style,
  compact,
}: {
  title: string;
  onPress: () => void;
  variant?: ButtonVariant;
  loading?: boolean;
  disabled?: boolean;
  icon?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  compact?: boolean;
}) {
  const filled = variant === 'primary' || variant === 'pro' || variant === 'dark';
  const bg =
    variant === 'primary' ? colors.primary
    : variant === 'pro' ? colors.pro
    : variant === 'dark' ? colors.dark
    : variant === 'secondary' || variant === 'danger' ? colors.surface
    : 'transparent';
  const fg = filled ? '#fff' : variant === 'danger' ? colors.danger : colors.primaryText;
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      accessibilityRole="button"
      style={({ pressed }) => [
        styles.button,
        compact && styles.buttonCompact,
        { backgroundColor: bg },
        (variant === 'secondary' || variant === 'danger') && styles.buttonOutline,
        (disabled || loading) && { opacity: 0.5 },
        pressed && { opacity: 0.85 },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={fg} />
      ) : (
        <View style={styles.buttonInner}>
          {icon}
          <Text style={[styles.buttonText, compact && { fontSize: 14 }, { color: fg }]}>{title}</Text>
        </View>
      )}
    </Pressable>
  );
}

export function TextField({ label, style, ...props }: TextInputProps & { label?: string }) {
  return (
    <View style={{ gap: 6 }}>
      {label && <Text style={styles.fieldLabel}>{label}</Text>}
      <TextInput placeholderTextColor={colors.textSubtle} style={[styles.input, style]} {...props} />
    </View>
  );
}

export function Chip({ label, selected, onPress }: { label: string; selected?: boolean; onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityState={{ selected }}
      style={[styles.chip, selected && styles.chipSelected]}
    >
      <Text style={[styles.chipText, selected && { color: colors.primaryText }]}>{label}</Text>
    </Pressable>
  );
}

/** Soft purple "🔒 Pro" pill. */
export function ProBadge({ label, locked = true }: { label?: string; locked?: boolean }) {
  const { t } = useI18n();
  return (
    <View style={styles.proBadge}>
      {locked && <Feather name="lock" size={10} color={colors.proText} />}
      <Text style={styles.proBadgeText}>{label ?? t('common.proShort')}</Text>
    </View>
  );
}

/** Uppercase small section label ("CATEGORIES", "RECENT SCANS"). */
export function SectionLabel({ title, right }: { title: string; right?: React.ReactNode }) {
  return (
    <View style={styles.sectionLabelRow}>
      <Text style={styles.sectionLabel}>{title}</Text>
      {right}
    </View>
  );
}

export function Card({ children, style }: { children: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function Loading() {
  return (
    <View style={styles.center}>
      <ActivityIndicator color={colors.primary} size="large" />
    </View>
  );
}

export function ErrorState({ onRetry, message }: { onRetry?: () => void; message?: string }) {
  const { t } = useI18n();
  return (
    <View style={[styles.center, { gap: spacing.md, padding: spacing.xxl }]}>
      <Feather name="alert-circle" size={32} color={colors.textMuted} />
      <Text style={font.h3}>{t('common.error')}</Text>
      <Text style={[font.bodyMuted, { textAlign: 'center' }]}>{message ?? t('common.errorBody')}</Text>
      {onRetry && <Button title={t('common.retry')} onPress={onRetry} variant="secondary" />}
    </View>
  );
}

const styles = StyleSheet.create({
  appHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.md,
  },
  goPro: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.proLight,
    borderRadius: radius.pill,
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
  goProText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  circleButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  button: {
    height: 52,
    borderRadius: radius.pill,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xxl,
  },
  buttonCompact: { height: 42, paddingHorizontal: spacing.lg },
  buttonOutline: { borderWidth: 1, borderColor: colors.border },
  buttonInner: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  buttonText: { fontSize: 16, fontWeight: '700' },
  fieldLabel: { fontSize: 13, fontWeight: '600', color: colors.textBody },
  input: {
    minHeight: 50,
    borderRadius: radius.md,
    backgroundColor: colors.surfaceMuted,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    fontSize: 15,
    color: colors.textBody,
  },
  chip: {
    paddingHorizontal: spacing.lg,
    paddingVertical: 8,
    borderRadius: radius.pill,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
  },
  chipSelected: { backgroundColor: colors.primarySoft, borderColor: colors.primarySoft },
  chipText: { fontSize: 14, fontWeight: '600', color: colors.textMuted },
  proBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: colors.proSoft,
    borderRadius: radius.pill,
    paddingHorizontal: 8,
    paddingVertical: 3,
    alignSelf: 'flex-start',
  },
  proBadgeText: { color: colors.proText, fontSize: 11, fontWeight: '700' },
  sectionLabelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: spacing.xxl,
    marginBottom: spacing.md,
  },
  sectionLabel: { fontSize: 12, fontWeight: '700', letterSpacing: 0.8, color: colors.textMuted },
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
    ...shadow.card,
  },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
});
