import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import { colors, spacing } from '@/src/constants/theme';
import { useI18n } from '@/src/context/LanguageContext';
import { BackChevron, CircleButton } from './ui';

/** Back button + title for pushed (non-tab) screens. */
export function StackHeader({ title, right }: { title?: string; right?: React.ReactNode }) {
  const { t } = useI18n();
  return (
    <View style={styles.row}>
      <CircleButton
        label={t('common.back')}
        onPress={() => (router.canGoBack() ? router.back() : router.replace('/'))}
      >
        <BackChevron />
      </CircleButton>
      <Text style={styles.title} numberOfLines={1}>
        {title}
      </Text>
      <View style={{ minWidth: 44, alignItems: 'flex-end' }}>{right}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    marginTop: spacing.sm,
    marginBottom: spacing.lg,
  },
  title: { flex: 1, fontSize: 18, fontWeight: '800', color: colors.text, textAlign: 'center' },
});
