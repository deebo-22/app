import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { colors, radius, shadow, spacing } from '@/src/constants/theme';
import { useI18n } from '@/src/context/LanguageContext';
import { Ring } from './Score';
import { Button } from './ui';

/**
 * Upsell card shown in place of Pro content for Free users. Deliberate teaser
 * (brief §4.2): a faded preview of what Pro shows, a "Pro feature" pill, and a
 * purple Go Pro button — the section stays visible, just locked.
 */
export function ProGate({
  title,
  body,
  preview = true,
  bare = false,
}: {
  title?: string;
  body?: string;
  preview?: boolean;
  /** Render without its own card chrome (when already inside a card). */
  bare?: boolean;
}) {
  const { t } = useI18n();
  return (
    <View style={bare ? styles.bare : styles.card}>
      {preview && (
        <View style={styles.preview} pointerEvents="none">
          <FakeRing color={colors.judgment.good} label={t('home.ringCalories')} />
          <FakeRing color={colors.primary} label={t('home.ringProtein')} />
          <FakeRing color={colors.proLight} label={t('home.ringWeight')} />
        </View>
      )}
      <View style={styles.content}>
        <View style={styles.pill}>
          <Feather name="lock" size={11} color={colors.proText} />
          <Text style={styles.pillText}>{t('common.proFeature')}</Text>
        </View>
        {title !== '' && <Text style={styles.title}>{title ?? t('proGate.title')}</Text>}
        <Text style={styles.body}>{body ?? t('proGate.body')}</Text>
        <Button
          title={t('common.goPro')}
          variant="pro"
          compact
          onPress={() => router.push('/paywall')}
          style={{ marginTop: 4 }}
        />
      </View>
    </View>
  );
}

function FakeRing({ color, label }: { color: string; label: string }) {
  return (
    <View style={{ alignItems: 'center', gap: 4 }}>
      <Ring percent={65} size={52} stroke={5} color={color} />
      <Text style={styles.fakeLabel}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: 'hidden',
    ...shadow.card,
  },
  bare: { overflow: 'hidden' },
  preview: {
    ...StyleSheet.absoluteFillObject,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    opacity: 0.18,
  },
  content: { alignItems: 'center', gap: 8, padding: spacing.xl },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: colors.proSoft,
    borderRadius: radius.pill,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  pillText: { fontSize: 12, fontWeight: '700', color: colors.proText },
  title: { fontSize: 17, fontWeight: '800', color: colors.text, textAlign: 'center' },
  body: { fontSize: 13, color: colors.textMuted, lineHeight: 19, textAlign: 'center' },
  fakeLabel: { fontSize: 10, color: colors.textMuted },
});
