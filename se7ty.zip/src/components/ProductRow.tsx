import React from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { colors, radius, spacing } from '@/src/constants/theme';
import { useI18n } from '@/src/context/LanguageContext';
import type { ProductCategory, ProductDetail } from '@/src/types/database';
import { calculateScore } from '@/src/utils/scoring';
import { ScoreRing, VerdictPill } from './Score';

export function productDisplayName(p: { name: string; name_ar: string | null }, language: 'ar' | 'en') {
  return language === 'ar' && p.name_ar ? p.name_ar : p.name;
}

export const CATEGORY_ICON: Record<ProductCategory, { icon: React.ComponentProps<typeof MaterialCommunityIcons>['name']; color: string; bg: string }> = {
  food: { icon: 'food-apple', color: '#E0483E', bg: '#FDECEA' },
  cosmetics: { icon: 'lotion-outline', color: '#E27AA0', bg: '#FCEBF2' },
  supplements: { icon: 'pill', color: '#E0703E', bg: '#FDF0E7' },
};

export function ProductImage({
  uri,
  size,
  category = 'food',
}: {
  uri: string | null;
  size: number;
  category?: ProductCategory;
}) {
  const c = CATEGORY_ICON[category];
  return (
    <View style={[styles.imageBox, { width: size, height: size, backgroundColor: uri ? colors.surfaceMuted : c.bg }]}>
      {uri ? (
        <Image source={{ uri }} style={{ width: size - 8, height: size - 8 }} resizeMode="contain" />
      ) : (
        <MaterialCommunityIcons name={c.icon} size={size * 0.5} color={c.color} />
      )}
    </View>
  );
}

/** Row used for Recent Scans, History, and Search results. */
export function ProductRow({ product }: { product: ProductDetail }) {
  const { language, t } = useI18n();
  const { score, verdict } = calculateScore(product);
  const meta = [product.brand, t(`category.${product.category}`)].filter(Boolean).join(' · ');
  return (
    <Pressable
      onPress={() => router.push(`/product/${product.id}`)}
      accessibilityRole="button"
      style={({ pressed }) => [styles.row, pressed && { opacity: 0.8 }]}
    >
      <ProductImage uri={product.image_url} size={44} category={product.category} />
      <View style={styles.body}>
        <Text style={styles.name} numberOfLines={1}>
          {productDisplayName(product, language)}
        </Text>
        <Text style={styles.meta} numberOfLines={1}>
          {meta}
        </Text>
      </View>
      {verdict && <VerdictPill verdict={verdict} />}
      <ScoreRing score={score} verdict={verdict} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
    paddingVertical: 10,
    marginBottom: spacing.sm,
  },
  imageBox: {
    borderRadius: radius.sm,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  body: { flex: 1, gap: 2 },
  name: { fontSize: 15, fontWeight: '700', color: colors.text },
  meta: { fontSize: 12, color: colors.primaryText },
});
