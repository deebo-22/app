import { supabase } from './supabase';
import { addDiaryEntry } from './progress';
import type { DiaryMealType } from '@/src/types/database';

export interface RecognizedItem {
  food_name: string;
  calories: number;
  protein_g: number;
  carbs_g: number;
  fat_g: number;
  confidence: number;
}

export interface RecognitionResult {
  items: RecognizedItem[];
  /** True while this is the stub. The UI shows a "demo data" banner when set. */
  isMock: boolean;
}

/**
 * ============================================================================
 *  STUB — no meal-recognition vendor has been chosen yet (brief §8 item 1).
 * ============================================================================
 * Returns fixed demo data after a short delay. When a vendor is selected:
 *   1. Do NOT call the vendor from the app with an API key in the bundle.
 *      Put the call in a Supabase Edge Function that (a) verifies the caller's
 *      JWT, (b) checks profiles.subscription_tier = 'pro' server-side, and
 *      (c) rate-limits per user — each call costs real money.
 *   2. Upload the photo to a private Storage bucket and pass its path.
 *   3. Replace this function body with a call to that Edge Function.
 */
export async function recognizeMeal(_photoUri: string): Promise<RecognitionResult> {
  await new Promise((r) => setTimeout(r, 1200));
  return {
    isMock: true,
    items: [
      { food_name: 'Koshari (1 plate)', calories: 620, protein_g: 18, carbs_g: 110, fat_g: 12, confidence: 0.5 },
      { food_name: 'Green salad', calories: 45, protein_g: 2, carbs_g: 8, fat_g: 0.5, confidence: 0.5 },
    ],
  };
}

/** Saves a recognized meal and logs it to today's diary as one entry. */
export async function saveMealToDiary(
  userId: string,
  items: RecognizedItem[],
  mealType: DiaryMealType,
) {
  const totals = items.reduce(
    (a, i) => ({
      calories: a.calories + i.calories,
      protein: a.protein + i.protein_g,
      carbs: a.carbs + i.carbs_g,
      fat: a.fat + i.fat_g,
    }),
    { calories: 0, protein: 0, carbs: 0, fat: 0 },
  );

  const { data: meal, error } = await supabase
    .from('meals')
    .insert({
      user_id: userId,
      photo_url: null, // photo upload is part of the vendor integration (see recognizeMeal)
      status: 'processed',
      total_calories: totals.calories,
      total_protein_g: totals.protein,
      total_carbs_g: totals.carbs,
      total_fat_g: totals.fat,
    })
    .select('id')
    .single();
  if (error) throw error;

  const { error: itemsError } = await supabase
    .from('meal_items')
    .insert(items.map((i) => ({ meal_id: meal.id, ...i })));
  if (itemsError) throw itemsError;

  await addDiaryEntry(userId, {
    meal_type: mealType,
    meal_id: meal.id,
    calories: totals.calories,
    protein_g: totals.protein,
    carbs_g: totals.carbs,
    fat_g: totals.fat,
  });
}
