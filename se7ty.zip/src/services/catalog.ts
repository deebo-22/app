/**
 * User contributions to the catalog: favorites, submissions, and issue reports.
 *
 * Submissions go into a moderation queue (`product_submissions`). They NEVER
 * write to `products` directly — promoting one is an admin action done with the
 * service role on the backend (brief §5.3).
 */
import { supabase } from './supabase';
import type { ProductCategory } from '@/src/types/database';

export async function isFavorite(userId: string, productId: string): Promise<boolean> {
  const { data, error } = await supabase
    .from('favorites')
    .select('product_id')
    .eq('user_id', userId)
    .eq('product_id', productId)
    .maybeSingle();
  if (error) throw error;
  return !!data;
}

export async function setFavorite(userId: string, productId: string, favorite: boolean) {
  const { error } = favorite
    ? await supabase
        .from('favorites')
        .upsert({ user_id: userId, product_id: productId }, { ignoreDuplicates: true })
    : await supabase.from('favorites').delete().eq('user_id', userId).eq('product_id', productId);
  if (error) throw error;
}

export interface SubmissionData {
  name: string;
  brand?: string;
  category: ProductCategory;
  serving_unit: '100g' | '100ml';
  nutrition?: {
    energy_kcal?: number | null;
    sugar_g?: number | null;
    saturates_g?: number | null;
    salt_g?: number | null;
    protein_g?: number | null;
    carbs_g?: number | null;
    fiber_g?: number | null;
  };
  ingredients_text?: string;
  // TODO: photo_urls once a private Storage bucket for submission photos is set up.
}

export async function submitProduct(userId: string, barcode: string, data: SubmissionData) {
  const { error } = await supabase.from('product_submissions').insert({
    submitted_by: userId,
    barcode: barcode.replace(/\D/g, ''),
    raw_data: data,
  });
  if (error) throw error;
}

export async function reportProductIssue(userId: string, productId: string, description: string) {
  const { error } = await supabase.from('product_reports').insert({
    product_id: productId,
    reported_by: userId,
    issue_description: description.trim().slice(0, 2000),
  });
  if (error) throw error;
}
