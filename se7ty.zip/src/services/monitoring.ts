import * as Sentry from '@sentry/react-native';
import { env } from '@/src/constants/env';

let initialized = false;

/** Initializes Sentry crash reporting when a DSN is configured. Safe to call more than once. */
export function initMonitoring() {
  if (initialized || !env.sentryDsn) return;
  Sentry.init({
    dsn: env.sentryDsn,
    // Don't attach IPs / request bodies by default — this app handles health-adjacent data.
    sendDefaultPii: false,
    tracesSampleRate: __DEV__ ? 1.0 : 0.2,
    enabled: !__DEV__,
  });
  initialized = true;
}

/** Tag errors with the Supabase user id only (no email / name). */
export function setMonitoringUser(userId: string | null) {
  if (!initialized) return;
  Sentry.setUser(userId ? { id: userId } : null);
}

export function captureError(error: unknown) {
  if (initialized) Sentry.captureException(error);
  if (__DEV__) console.warn(error);
}

export { Sentry };
