/**
 * RevenueCat client wrapper.
 *
 * IMPORTANT — the client never decides whether a user is Pro. It only starts
 * purchases. After a purchase, RevenueCat calls our webhook
 * (supabase/functions/revenuecat-webhook), which writes profiles.subscription_tier
 * with the service role. The app then re-reads the profile. A tampered client
 * can at most show itself a Pro-looking UI; it cannot grant itself server access.
 *
 * react-native-purchases needs a development build (`npx expo run:android|ios`
 * or EAS). In Expo Go it runs in a limited preview mode, so everything here is
 * wrapped defensively.
 */
import { Platform } from 'react-native';
import Purchases, { type PurchasesPackage } from 'react-native-purchases';
import { env } from '@/src/constants/env';

let configuredFor: string | null = null;

function apiKey() {
  return Platform.OS === 'ios' ? env.revenueCatIosKey : env.revenueCatAndroidKey;
}

export function isPurchasesConfigured() {
  return Boolean(apiKey());
}

/** Configure RevenueCat with the Supabase user id so webhook events map to profiles.id. */
export async function configurePurchases(userId: string) {
  if (!apiKey() || configuredFor === userId) return;
  try {
    if (configuredFor) {
      await Purchases.logIn(userId);
    } else {
      Purchases.configure({ apiKey: apiKey(), appUserID: userId });
    }
    configuredFor = userId;
  } catch (e) {
    console.warn('[purchases] configure failed', e);
  }
}

export async function resetPurchases() {
  if (!configuredFor) return;
  try {
    await Purchases.logOut();
  } catch {
    // logOut throws if the current user is anonymous — safe to ignore.
  }
  configuredFor = null;
}

export async function getPackages(): Promise<PurchasesPackage[]> {
  const offerings = await Purchases.getOfferings();
  return offerings.current?.availablePackages ?? [];
}

export async function purchase(pkg: PurchasesPackage) {
  return Purchases.purchasePackage(pkg);
}

export async function restorePurchases() {
  return Purchases.restorePurchases();
}
