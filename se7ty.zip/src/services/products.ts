import { supabase } from './supabase';
import type {
  ProductAdditive,
  ProductCategory,
  ProductDetail,
  ProductIngredient,
  ProductNutrition,
} from '@/src/types/database';
import { calculateScore } from '@/src/utils/scoring';

/** Columns + joins needed to render and score a product. */
export const PRODUCT_DETAIL_SELECT = `
  id, barcode, category, name, name_ar, brand, image_url, serving_unit, source, verified, created_at, updated_at,
  product_nutrition ( product_id, energy_kcal, sugar_g, saturates_g, salt_g, protein_g, carbs_g, fiber_g ),
  product_additives ( id, product_id, code, name, risk_level ),
  product_ingredients ( id, product_id, ingredient_name, sort_order )
`;

type RawProduct = Omit<ProductDetail, 'nutrition' | 'additives' | 'ingredients'> & {
  product_nutrition: ProductNutrition | ProductNutrition[] | null;
  product_additives: ProductAdditive[] | null;
  product_ingredients: ProductIngredient[] | null;
};

/** PostgREST returns a 1:1 join as an object, but be defensive in case it's an array. */
export function normalizeProduct(raw: RawProduct): ProductDetail {
  const { product_nutrition, product_additives, product_ingredients, ...rest } = raw;
  const nutrition = Array.isArray(product_nutrition)
    ? (product_nutrition[0] ?? null)
    : (product_nutrition ?? null);
  return {
    ...rest,
    nutrition,
    additives: product_additives ?? [],
    ingredients: [...(product_ingredients ?? [])].sort((a, b) => a.sort_order - b.sort_order),
  };
}

/**
 * Barcode variants to try. Scanners disagree on UPC-A vs EAN-13: iOS reports a
 * 12-digit UPC-A as 13 digits with a leading 0, Android may not.
 */
export function barcodeVariants(input: string): string[] {
  const digits = input.replace(/\D/g, '');
  if (!digits) return [];
  const set = new Set([digits]);
  if (digits.length === 12) set.add(`0${digits}`);
  if (digits.length === 13 && digits.startsWith('0')) set.add(digits.slice(1));
  return [...set];
}

export async function findProductIdByBarcode(barcode: string): Promise<string | null> {
  const variants = barcodeVariants(barcode);
  if (variants.length === 0) return null;
  const { data, error } = await supabase
    .from('products')
    .select('id')
    .in('barcode', variants)
    .limit(1)
    .maybeSingle();
  if (error) throw error;
  return data?.id ?? null;
}

export async function getProductDetail(id: string): Promise<ProductDetail | null> {
  const { data, error } = await supabase
    .from('products')
    .select(PRODUCT_DETAIL_SELECT)
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data ? normalizeProduct(data as unknown as RawProduct) : null;
}

/**
 * Strip characters that have meaning inside a PostgREST `or=(...)` filter string
 * (commas, parentheses, quotes, wildcards, backslashes). Without this, a search
 * like "a,brand.eq.x" could inject extra filter clauses. RLS still limits what's
 * readable, but we don't want users rewriting our queries.
 */
function sanitizeSearch(q: string) {
  return q.replace(/[,()"'\\%*:]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 60);
}

export async function searchProducts(
  query: string,
  category?: ProductCategory,
): Promise<ProductDetail[]> {
  const q = sanitizeSearch(query);
  let req = supabase.from('products').select(PRODUCT_DETAIL_SELECT).limit(30);
  if (category) req = req.eq('category', category);
  if (q) {
    // TODO(brief §8.3): Arabic ↔ English matching (e.g. "زبادي" → "yogurt") needs a
    // proper search strategy once real catalog data exists. This is plain substring match.
    req = req.or(`name.ilike.*${q}*,name_ar.ilike.*${q}*,brand.ilike.*${q}*`);
  } else {
    req = req.order('name');
  }
  const { data, error } = await req;
  if (error) throw error;
  return ((data ?? []) as unknown as RawProduct[]).map(normalizeProduct);
}

/** Same-category products that score better than the given one, best first. */
export async function getRecommendations(product: ProductDetail): Promise<ProductDetail[]> {
  const { data, error } = await supabase
    .from('products')
    .select(PRODUCT_DETAIL_SELECT)
    .eq('category', product.category)
    .neq('id', product.id)
    .limit(40);
  if (error) throw error;
  const base = calculateScore(product).score ?? 0;
  return ((data ?? []) as unknown as RawProduct[])
    .map(normalizeProduct)
    .map((p) => ({ p, s: calculateScore(p).score }))
    .filter((x): x is { p: ProductDetail; s: number } => x.s != null && x.s > base)
    .sort((a, b) => b.s - a.s)
    .slice(0, 10)
    .map((x) => x.p);
}
