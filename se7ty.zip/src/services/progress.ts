/**
 * My Progress data: diary (calories/macros), weight logs, and goals.
 * All tables are owner-scoped by RLS; the explicit user_id filters are for
 * clarity and index use, not security.
 */
import { supabase } from './supabase';
import type { DiaryEntry, DiaryMealType, UserGoals, WeightLog } from '@/src/types/database';
import { localDateString } from '@/src/utils/date';

export async function getDiaryForDate(userId: string, date = localDateString()): Promise<DiaryEntry[]> {
  const { data, error } = await supabase
    .from('diary_entries')
    .select('*')
    .eq('user_id', userId)
    .eq('logged_date', date)
    .order('created_at');
  if (error) throw error;
  return (data ?? []) as DiaryEntry[];
}

export interface NewDiaryEntry {
  meal_type: DiaryMealType;
  calories: number;
  protein_g?: number | null;
  carbs_g?: number | null;
  fat_g?: number | null;
  /** Exactly one of these must be set (enforced by the one_source_check constraint). */
  manual_label?: string;
  product_id?: string;
  meal_id?: string;
}

export async function addDiaryEntry(userId: string, entry: NewDiaryEntry) {
  const { error } = await supabase.from('diary_entries').insert({
    user_id: userId,
    logged_date: localDateString(),
    ...entry,
  });
  if (error) throw error;
}

export async function deleteDiaryEntry(id: string) {
  const { error } = await supabase.from('diary_entries').delete().eq('id', id);
  if (error) throw error;
}

export async function getWeightLogs(userId: string, limit = 30): Promise<WeightLog[]> {
  const { data, error } = await supabase
    .from('weight_logs')
    .select('*')
    .eq('user_id', userId)
    .order('logged_date', { ascending: false })
    .limit(limit);
  if (error) throw error;
  return ((data ?? []) as WeightLog[]).reverse(); // oldest → newest for charting
}

/** One weight per day — logging again today overwrites today's value. */
export async function logWeight(userId: string, weightKg: number) {
  const { error } = await supabase
    .from('weight_logs')
    .upsert(
      { user_id: userId, logged_date: localDateString(), weight_kg: weightKg },
      { onConflict: 'user_id,logged_date' },
    );
  if (error) throw error;
}

export async function getGoals(userId: string): Promise<UserGoals | null> {
  const { data, error } = await supabase
    .from('user_goals')
    .select('*')
    .eq('user_id', userId)
    .maybeSingle();
  if (error) throw error;
  return data as UserGoals | null;
}

export async function saveGoals(
  userId: string,
  goals: Partial<Omit<UserGoals, 'user_id' | 'updated_at'>>,
) {
  const { error } = await supabase
    .from('user_goals')
    .upsert({ user_id: userId, ...goals, updated_at: new Date().toISOString() });
  if (error) throw error;
}

export function sumDiary(entries: DiaryEntry[]) {
  return entries.reduce(
    (acc, e) => ({
      calories: acc.calories + (e.calories ?? 0),
      protein: acc.protein + (e.protein_g ?? 0),
      carbs: acc.carbs + (e.carbs_g ?? 0),
      fat: acc.fat + (e.fat_g ?? 0),
    }),
    { calories: 0, protein: 0, carbs: 0, fat: 0 },
  );
}
