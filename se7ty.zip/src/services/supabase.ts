import 'react-native-url-polyfill/auto';
import { AppState, Platform } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import { createClient } from '@supabase/supabase-js';
import { env } from '@/src/constants/env';

/**
 * Session storage backed by the OS keychain (iOS) / Keystore-encrypted prefs (Android)
 * instead of plain AsyncStorage, so refresh tokens aren't readable from app storage
 * on a rooted/jailbroken or backed-up device.
 *
 * SecureStore warns on values above ~2 KB and a Supabase session can exceed that,
 * so values are split into chunks under `<key>.<n>` with a chunk count in `<key>`.
 */
const CHUNK_SIZE = 1800;

const secureStoreAdapter = {
  async getItem(key: string): Promise<string | null> {
    const countRaw = await SecureStore.getItemAsync(safeKey(key));
    if (countRaw == null) return null;
    const count = Number(countRaw);
    if (!Number.isInteger(count) || count < 0) return null;
    const parts: string[] = [];
    for (let i = 0; i < count; i++) {
      const part = await SecureStore.getItemAsync(safeKey(`${key}.${i}`));
      if (part == null) return null; // partial write — treat as signed out
      parts.push(part);
    }
    return parts.join('');
  },
  async setItem(key: string, value: string): Promise<void> {
    await secureStoreAdapter.removeItem(key);
    const count = Math.ceil(value.length / CHUNK_SIZE);
    for (let i = 0; i < count; i++) {
      await SecureStore.setItemAsync(
        safeKey(`${key}.${i}`),
        value.slice(i * CHUNK_SIZE, (i + 1) * CHUNK_SIZE),
      );
    }
    await SecureStore.setItemAsync(safeKey(key), String(count));
  },
  async removeItem(key: string): Promise<void> {
    const countRaw = await SecureStore.getItemAsync(safeKey(key));
    const count = Number(countRaw ?? 0);
    for (let i = 0; i < (Number.isInteger(count) ? count : 0); i++) {
      await SecureStore.deleteItemAsync(safeKey(`${key}.${i}`));
    }
    await SecureStore.deleteItemAsync(safeKey(key));
  },
};

// SecureStore keys may only contain alphanumerics, ".", "-" and "_".
function safeKey(key: string) {
  return key.replace(/[^A-Za-z0-9._-]/g, '_');
}

export const supabase = createClient(
  env.supabaseUrl || 'https://not-configured.supabase.co',
  env.supabaseAnonKey || 'not-configured',
  {
    auth: {
      storage: Platform.OS === 'web' ? undefined : secureStoreAdapter,
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: false,
    },
  },
);

// Only refresh tokens while the app is in the foreground (Supabase's recommended RN setup).
if (Platform.OS !== 'web') {
  AppState.addEventListener('change', (state) => {
    if (state === 'active') supabase.auth.startAutoRefresh();
    else supabase.auth.stopAutoRefresh();
  });
}
