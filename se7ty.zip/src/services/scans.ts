import { supabase } from './supabase';
import { PRODUCT_DETAIL_SELECT, normalizeProduct } from './products';
import type { ScanWithProduct } from '@/src/types/database';
import { calculateScore } from '@/src/utils/scoring';

export async function recordScan(userId: string, productId: string) {
  const { error } = await supabase
    .from('scans')
    .insert({ user_id: userId, product_id: productId, source: 'barcode' });
  if (error) throw error;
}

/**
 * Most recent scans, newest first, one row per product (re-scanning the same
 * product just moves it to the top instead of duplicating it in the list).
 */
export async function getRecentScans(limit = 5): Promise<ScanWithProduct[]> {
  const { data, error } = await supabase
    .from('scans')
    .select(`id, scanned_at, product:products ( ${PRODUCT_DETAIL_SELECT} )`)
    .order('scanned_at', { ascending: false })
    .limit(Math.max(limit * 4, 20));
  if (error) throw error;

  const seen = new Set<string>();
  const out: ScanWithProduct[] = [];
  for (const row of (data ?? []) as any[]) {
    const raw = Array.isArray(row.product) ? row.product[0] : row.product;
    if (!raw || seen.has(raw.id)) continue;
    seen.add(raw.id);
    out.push({ id: row.id, scanned_at: row.scanned_at, product: normalizeProduct(raw) });
    if (out.length >= limit) break;
  }
  return out;
}

export async function deleteProductFromHistory(productId: string) {
  // RLS restricts the delete to the signed-in user's own scans.
  const { error } = await supabase.from('scans').delete().eq('product_id', productId);
  if (error) throw error;
}

/** "Your impact" — share of the last N distinct scanned products that score ≥ 50. */
export async function getImpact(sampleSize = 15) {
  const scans = await getRecentScans(sampleSize);
  const scores = scans
    .map((s) => calculateScore(s.product).score)
    .filter((s): s is number => s != null);
  if (scores.length === 0) return { percent: null as number | null, count: 0 };
  const good = scores.filter((s) => s >= 50).length;
  return { percent: Math.round((good / scores.length) * 100), count: scores.length };
}
