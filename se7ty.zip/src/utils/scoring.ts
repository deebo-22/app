/**
 * ============================================================================
 *  ⚠️  PLACEHOLDER SCORING — NOT THE REAL SE7TY METHODOLOGY  ⚠️
 * ============================================================================
 * This exists so the product screen has something to render. The weights and
 * thresholds below are rough, Yuka-inspired guesses. Before any real user sees
 * a score, the methodology needs a dedicated design pass (brief §8 item 2):
 *   - how sugar / saturates / salt / energy / additives trade off
 *   - separate models for cosmetics and supplements (they have no nutrition)
 *   - a legal review of the verdict wording (brief §9 item 3)
 *
 * Scores are ALWAYS computed at request time from raw data — never stored —
 * so changing this file re-scores every product instantly, no migration.
 * Keep `SCORING_IS_PLACEHOLDER` true until the real method replaces this; the
 * UI uses it to show a "preliminary score" notice.
 * ============================================================================
 */
import type { AdditiveRisk, ProductDetail } from '@/src/types/database';

export const SCORING_IS_PLACEHOLDER = true;

export type Judgment = 'excellent' | 'good' | 'poor' | 'bad';
export type NutrientKey = 'additives' | 'sugar' | 'saturates' | 'salt' | 'energy' | 'protein' | 'fiber';

export interface NutrientAssessment {
  key: NutrientKey;
  value: number;
  unit: 'g' | 'kcal' | '';
  judgment: Judgment;
  /** Threshold boundaries (ascending) used to draw the scale bar. */
  thresholds?: number[];
  /** For "more is better" nutrients (protein, fiber) the scale is reversed. */
  higherIsBetter?: boolean;
  /** Worst additive risk tier present; only set on the additives row. */
  worstRisk?: AdditiveRisk | 'none';
}

export interface ScoreResult {
  /** 0–100, or null when there isn't enough data to score. */
  score: number | null;
  verdict: Judgment | null;
  negatives: NutrientAssessment[];
  positives: NutrientAssessment[];
}

// Thresholds are the upper bounds for excellent / good / poor; above the last is bad.
const SOLID_THRESHOLDS: Record<'sugar' | 'saturates' | 'salt' | 'energy', number[]> = {
  sugar: [4.5, 9, 18],
  saturates: [1, 2, 5],
  salt: [0.46, 0.92, 1.62],
  energy: [160, 360, 560],
};

const LIQUID_THRESHOLDS: Record<'sugar' | 'saturates' | 'salt' | 'energy', number[]> = {
  sugar: [1.5, 3, 7],
  saturates: [1, 2, 5],
  salt: [0.46, 0.92, 1.62],
  energy: [14, 35, 60],
};

// Lower bounds for good / excellent.
const POSITIVE_THRESHOLDS: Record<'protein' | 'fiber', number[]> = {
  protein: [4, 8],
  fiber: [2, 3.5],
};

const PENALTY: Record<Judgment, number> = { excellent: 0, good: 5, poor: 15, bad: 30 };
const WEIGHT: Record<'sugar' | 'saturates' | 'salt' | 'energy', number> = {
  sugar: 1.3,
  saturates: 1,
  salt: 1,
  energy: 0.8,
};
const ADDITIVE_PENALTY: Record<AdditiveRisk, number> = {
  no_risk: 0,
  limited_risk: 3,
  moderate_risk: 10,
  high_risk: 25,
};

const RISK_ORDER: AdditiveRisk[] = ['no_risk', 'limited_risk', 'moderate_risk', 'high_risk'];

function judgeLowerIsBetter(value: number, t: number[]): Judgment {
  if (value <= t[0]) return 'excellent';
  if (value <= t[1]) return 'good';
  if (value <= t[2]) return 'poor';
  return 'bad';
}

function judgeHigherIsBetter(value: number, t: number[]): Judgment | null {
  if (value >= t[1]) return 'excellent';
  if (value >= t[0]) return 'good';
  return null; // not notable — don't show as a positive
}

export function verdictForScore(score: number): Judgment {
  if (score >= 75) return 'excellent';
  if (score >= 50) return 'good';
  if (score >= 25) return 'poor';
  return 'bad';
}

function isNegative(j: Judgment) {
  return j === 'poor' || j === 'bad';
}

export function calculateScore(product: ProductDetail): ScoreResult {
  const assessments: NutrientAssessment[] = [];
  let penalty = 0;
  let bonus = 0;
  let hasData = false;

  // --- Additives -----------------------------------------------------------
  const additives = product.additives ?? [];
  const worst = additives.reduce<AdditiveRisk | null>((acc, a) => {
    if (!acc) return a.risk_level;
    return RISK_ORDER.indexOf(a.risk_level) > RISK_ORDER.indexOf(acc) ? a.risk_level : acc;
  }, null);
  const additivePenalty = Math.min(
    40,
    additives.reduce((sum, a) => sum + ADDITIVE_PENALTY[a.risk_level], 0),
  );
  penalty += additivePenalty;
  const additiveJudgment: Judgment =
    !worst ? 'excellent'
    : worst === 'no_risk' ? 'good'
    : worst === 'limited_risk' ? 'poor'
    : 'bad';
  // Only claim "no additives" when we actually hold ingredient data for the product.
  if (additives.length > 0 || product.ingredients.length > 0) {
    hasData = true;
    assessments.push({
      key: 'additives',
      value: additives.length,
      unit: '',
      judgment: additiveJudgment,
      worstRisk: worst ?? 'none',
    });
  }

  // --- Nutrition (food only) ----------------------------------------------
  const n = product.nutrition;
  if (product.category === 'food' && n) {
    const table = product.serving_unit === '100ml' ? LIQUID_THRESHOLDS : SOLID_THRESHOLDS;
    const fields: [keyof typeof table, number | null, 'g' | 'kcal'][] = [
      ['sugar', n.sugar_g, 'g'],
      ['saturates', n.saturates_g, 'g'],
      ['salt', n.salt_g, 'g'],
      ['energy', n.energy_kcal, 'kcal'],
    ];
    for (const [key, value, unit] of fields) {
      if (value == null) continue;
      hasData = true;
      const judgment = judgeLowerIsBetter(value, table[key]);
      penalty += PENALTY[judgment] * WEIGHT[key];
      assessments.push({ key, value, unit, judgment, thresholds: table[key] });
    }
    const positives: [keyof typeof POSITIVE_THRESHOLDS, number | null][] = [
      ['protein', n.protein_g],
      ['fiber', n.fiber_g],
    ];
    for (const [key, value] of positives) {
      if (value == null) continue;
      const judgment = judgeHigherIsBetter(value, POSITIVE_THRESHOLDS[key]);
      if (!judgment) continue;
      bonus += judgment === 'excellent' ? 6 : 3;
      assessments.push({
        key,
        value,
        unit: 'g',
        judgment,
        thresholds: POSITIVE_THRESHOLDS[key],
        higherIsBetter: true,
      });
    }
  }

  if (!hasData) {
    return { score: null, verdict: null, negatives: [], positives: [] };
  }

  const score = Math.round(Math.max(0, Math.min(100, 100 - penalty + bonus)));
  return {
    score,
    verdict: verdictForScore(score),
    negatives: assessments.filter((a) => isNegative(a.judgment)),
    positives: assessments.filter((a) => !isNegative(a.judgment)),
  };
}
