/**
 * Hand-written row types mirroring supabase/migrations/0001_initial_schema.sql.
 *
 * Once the Supabase project exists, replace/verify these with generated types:
 *   npx supabase gen types typescript --project-id <ref> > src/types/supabase.generated.ts
 * Numeric columns come back from PostgREST as JS numbers; nullable columns as null.
 */

export type ProductCategory = 'food' | 'cosmetics' | 'supplements';
export type AdditiveRisk = 'no_risk' | 'limited_risk' | 'moderate_risk' | 'high_risk';
export type SubmissionStatus = 'pending' | 'approved' | 'rejected';
export type SubscriptionTier = 'free' | 'pro';
export type ScanSource = 'barcode' | 'meal_photo';
export type DiaryMealType = 'breakfast' | 'lunch' | 'dinner' | 'snack';
export type Language = 'ar' | 'en';

export interface Profile {
  id: string;
  display_name: string | null;
  preferred_language: Language;
  subscription_tier: SubscriptionTier;
  subscription_expires_at: string | null;
  revenuecat_app_user_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface Product {
  id: string;
  barcode: string;
  category: ProductCategory;
  name: string;
  name_ar: string | null;
  brand: string | null;
  image_url: string | null;
  serving_unit: '100g' | '100ml';
  source: 'seed' | 'open_food_facts' | 'user_submitted';
  verified: boolean;
  created_at: string;
  updated_at: string;
}

export interface ProductNutrition {
  product_id: string;
  energy_kcal: number | null;
  sugar_g: number | null;
  saturates_g: number | null;
  salt_g: number | null;
  protein_g: number | null;
  carbs_g: number | null;
  fiber_g: number | null;
}

export interface ProductAdditive {
  id: string;
  product_id: string;
  code: string;
  name: string;
  risk_level: AdditiveRisk;
}

export interface ProductIngredient {
  id: string;
  product_id: string;
  ingredient_name: string;
  sort_order: number;
}

/** A product with its related catalog data joined in — what scoring needs. */
export interface ProductDetail extends Product {
  nutrition: ProductNutrition | null;
  additives: ProductAdditive[];
  ingredients: ProductIngredient[];
}

export interface Scan {
  id: string;
  user_id: string;
  product_id: string;
  source: ScanSource;
  scanned_at: string;
}

export interface ScanWithProduct {
  id: string;
  scanned_at: string;
  product: ProductDetail;
}

export interface Meal {
  id: string;
  user_id: string;
  photo_url: string | null;
  status: 'pending' | 'processed' | 'failed';
  total_calories: number | null;
  total_protein_g: number | null;
  total_carbs_g: number | null;
  total_fat_g: number | null;
  created_at: string;
}

export interface MealItem {
  id: string;
  meal_id: string;
  food_name: string;
  calories: number | null;
  protein_g: number | null;
  carbs_g: number | null;
  fat_g: number | null;
  confidence: number | null;
}

export interface DiaryEntry {
  id: string;
  user_id: string;
  logged_date: string; // YYYY-MM-DD
  meal_type: DiaryMealType;
  product_id: string | null;
  meal_id: string | null;
  manual_label: string | null;
  calories: number;
  protein_g: number | null;
  carbs_g: number | null;
  fat_g: number | null;
  created_at: string;
}

export interface WeightLog {
  id: string;
  user_id: string;
  logged_date: string;
  weight_kg: number;
  created_at: string;
}

export interface UserGoals {
  user_id: string;
  daily_calorie_goal: number | null;
  protein_goal_g: number | null;
  carbs_goal_g: number | null;
  fat_goal_g: number | null;
  target_weight_kg: number | null;
  updated_at: string;
}
