# Se7ty — صحتي

*Smarter choices. Healthier you.* A barcode-scanning health-score app for Egypt (iOS + Android), built with Expo (SDK 57) + Expo Router, Supabase, RevenueCat and Sentry. The full product spec is in [docs_build_brief.md](docs_build_brief.md).

---

## 1. First-time setup (Windows)

1. **Install Node.js LTS** from https://nodejs.org (it isn't installed on this machine yet). Restart the terminal afterwards.
2. In this folder:
   ```bash
   npm install
   ```
   ```bash
   npm run setup
   ```
   `setup` runs `expo install`, which picks the dependency versions that match Expo SDK 57 and writes them into `package.json`. Run it once, then commit the updated `package.json` and `package-lock.json`.
3. Copy `.env.example` to `.env` and fill in your Supabase URL + anon key (Supabase dashboard → Project Settings → API).
4. Check for type errors and config problems:
   ```bash
   npm run typecheck
   ```
   ```bash
   npm run doctor
   ```

## 2. Database (Supabase)

In the Supabase dashboard → SQL Editor, run these **in order**:

| File | What it does |
|---|---|
| `supabase/migrations/0001_initial_schema.sql` | The approved schema + RLS (unchanged). |
| `supabase/migrations/0002_security_and_profiles.sql` | **Required.** Closes the security holes described below, adds the sign-up → profile trigger and `updated_at` triggers. |
| `supabase/seed.sql` | **Development only.** Three `[TEST]` products with fake barcodes (listed in the file) so you can test scanning. |

### Security fixes in 0002 (please review)
- **Entitlement spoofing:** in 0001, `profiles_update_own` let any signed-in user run `update profiles set subscription_tier='pro'` on their own row using only the public anon key. 0002 limits client updates to `display_name` and `preferred_language` with column-level grants. Only the service role (the webhook) can change the tier.
- **Moderation bypass:** clients could insert submissions with `status='approved'` or reports with `resolved=true`. They are now limited to the fields they legitimately provide.
- **No profile row:** nothing created a `profiles` row on sign-up. A trigger now does.

## 3. Running the app

```bash
npx expo start
```
- **Expo Go** (scan the QR code with your phone) works for UI, auth, scanning and the database.
- **RevenueCat purchases and Sentry need a development build**, not Expo Go:
  ```bash
  npx expo run:android
  ```
  (iOS builds need a Mac, or use EAS Build: `npx eas build --profile development`.)

To test scanning without a real product, open the Scan tab → "Enter barcode manually" → type `0000000000017` (the seeded test yogurt). Type `0000000000048` to test the "product not found → submit" flow.

## 4. Subscriptions (RevenueCat)

1. Create the app and products in RevenueCat and an entitlement called `pro`. Put the **public** SDK keys in `.env`.
2. Deploy the webhook (needs the Supabase CLI):
   ```bash
   npx supabase functions deploy revenuecat-webhook --no-verify-jwt
   ```
   ```bash
   npx supabase secrets set REVENUECAT_WEBHOOK_AUTH=<long-random-string> REVENUECAT_SECRET_API_KEY=<sk_...> REVENUECAT_ENTITLEMENT_ID=pro
   ```
3. In RevenueCat → Integrations → Webhooks, set the URL to `https://<project-ref>.supabase.co/functions/v1/revenuecat-webhook` and the Authorization header to the same `<long-random-string>`.

How it works: the app never marks itself Pro. After a purchase, RevenueCat calls the webhook. The webhook ignores the event body's claims, asks RevenueCat's API for the user's real entitlement, and writes `profiles.subscription_tier` using the service role. The app then re-reads the profile.

## 5. Project layout

```
app/                     Screens (Expo Router — the file path is the route)
  _layout.tsx            Providers + auth gate (Stack.Protected)
  (auth)/                Sign in / sign up
  (tabs)/                Home, Scan, My Progress, Profile
  product/[id].tsx       Product detail (score, Negatives/Positives, options, alternatives)
  submit.tsx             "Product not found" → moderation queue
  search.tsx, history.tsx, paywall.tsx, meal-scanner.tsx, scoring-method.tsx
src/
  constants/theme.ts     Colors, spacing, radius (from the UI references)
  context/               AuthContext (session, profile, isPro), LanguageContext (ar/en, RTL)
  i18n/strings.ts        All UI text, English + Arabic
  services/              Supabase client + data access, RevenueCat, Sentry
  utils/scoring.ts       ⚠️ PLACEHOLDER scoring algorithm
supabase/                Migrations, dev seed, RevenueCat webhook function
assets/                  Placeholder icons generated from the logo reference
```

## 6. Known placeholders / open items

- **Scoring (`src/utils/scoring.ts`) is a placeholder.** Products show a "preliminary score" notice while `SCORING_IS_PLACEHOLDER = true`. It needs a methodology pass and a legal review of the verdict wording before launch (brief §8.2, §9.3).
- **Meal Scanner recognition is stubbed** (`src/services/meals.ts`) and returns demo data with a visible banner. When a vendor is chosen, call it from an Edge Function that re-checks Pro on the server and rate-limits, never with a vendor key in the app.
- **Logo/icons** in `assets/` and `src/components/Logo.tsx` are recreations of the reference. Replace them with the real exported logo files.
- **Submission photos:** the submit form collects text only. Photo upload needs a private Storage bucket.
- **Arabic ⇄ English search matching** (brief §8.3) is plain substring matching for now.
- **Catalog seeding:** hand-seed the 50–100 common Egyptian staples before beta users arrive (brief §6). Otherwise most early scans will be "not found".
- **Pro gating is UI-level for tracking data.** A free user calling the API directly could write their own diary rows. That's harmless (it's their own data). Anything that **costs money** (meal recognition) must check the tier server-side.
- "Food preferences", Notifications and Help & support are "coming soon" stubs (there's no schema for them yet).
