# Se7ty — AI Build Brief

You are being brought in to continue building **Se7ty**, a native mobile app for the Egyptian market. This document is the complete product and technical specification. Read it in full before writing code. Where it references files (schema, existing scaffold), inspect those files directly rather than assuming their contents from this summary.

## How to work on this project

- Treat this as a long-lived codebase, not a one-off script. Prioritize correctness, security, and maintainability over speed of output.
- The founder (solo, non-developer background, security/pentesting professional by trade) will be directing you and reviewing your work, but is not comfortable writing the code themselves. Explain non-obvious decisions as you go; don't assume deep React Native/mobile-dev familiarity.
- Don't silently agree with a bad instruction. If something in this brief or a future request is insecure, unnecessarily complex, or likely to cause problems at scale, say so directly and explain the alternative — then proceed with whichever the founder confirms.
- Work in phases: understand → architect → build incrementally → verify. Don't rewrite working code unnecessarily; make targeted changes.
- Never hardcode secrets (Supabase keys, RevenueCat keys, Sentry DSN) — use environment variables per `.env.example`.
- Where you're not certain of a current library API (see "Known risks" below — Expo Router and expo-camera specifically have shifted APIs across recent SDK releases), verify against current documentation rather than assuming.

---

## 1. Product overview

**Se7ty** ("healthy" in Egyptian Arabic slang) is a barcode-scanning app that gives Egyptian consumers an instant, plain-language health score for packaged products — food, cosmetics, and supplements — based on their declared ingredients and nutrition facts. It is a **hybrid of two reference apps**:

- **UI/UX and visual polish**: modeled on **Oasis – What's Healthy** (clean, card-based, warm/minimal design language).
- **Core functionality**: modeled on **Yuka** (scan a barcode → instant score out of 100 → Negatives/Positives ingredient breakdown). **Se7ty does not do independent lab testing** — this is a label/ingredient-data scoring app, not a lab-verification app. (If you encounter any earlier research or notes referencing accredited labs, PFAS testing, or lab-partnership strategy, that was from an earlier version of this concept and is no longer the direction — see "Known risks," item 4, for what's still relevant from that research.)

Tagline: **"Smarter choices. Healthier you."**

## 2. Target market and strategic context

Egypt-only for v1. This matters architecturally, not just as a go-to-market detail:

- **The core opportunity is a data gap.** Open Food Facts has only ~3,500 Egyptian products cataloged; Yuka has essentially none. Neither Yuka nor Open Food Facts localize well for Egyptian/Arabic-labeled products. Se7ty's defensibility is having real Egyptian product data that competitors don't.
- **Supplements is the highest-stakes category.** Egypt has an active, ongoing problem with counterfeit and unregistered supplements marketed on social media, and the Egyptian Drug Authority has been publicly warning consumers about misleading supplement/pharma ads. A trustworthy score in this category is where Se7ty can matter most — and where the empty-database problem will sting hardest if not addressed pre-launch (see "Known risks," item 1).
- **Language**: the UI and product data need to support Arabic as a first-class language, not an afterthought bolt-on. The schema already has `name_ar` on products and a `preferred_language` field on user profiles — build with that in mind from the start rather than hardcoding English strings.

## 3. Branding and design language

- **Name**: Se7ty
- **Logo**: leaf mark + wordmark, deep forest green background, cream/white text — see provided logo asset.
- **Visual language**: warm off-white app background, dark green primary surfaces (hero cards, CTAs), a lighter leaf-green accent for icons/links/positive indicators, red/yellow/green dot system for score judgments — same pattern Yuka uses (see section 4.3 for exact field-level behavior).
- Placeholder hex values are in `src/constants/theme.ts` in the existing scaffold — treat these as approximate; pull exact values from the logo source file before anything ships to real users.

## 4. Feature specification

### 4.1 Free tier

- **Barcode Scanner**: scan a product → basic score only (score/100, verdict label, color dot). No deep nutrition breakdown.

### 4.2 Pro tier (subscription)

- Deep nutrition breakdown on scanned products: full calorie/macro detail, per-field Negatives/Positives rows (see 4.3).
- **Meal Scanner**: photograph a full meal/plate → app identifies food items and estimates nutrition. This is a **distinct capability from barcode scanning** (image-based food recognition vs. barcode lookup) and its backend vendor is not yet chosen — see "Open decisions," item 1. Build the feature's UI and data model (already scaffolded: `meals` / `meal_items` tables), but the actual recognition call should be a stubbed/mocked function until a vendor is selected.
- **Calorie tracking, macro tracking, weight tracking** — logged via `diary_entries` and `weight_logs` tables, surfaced in My Progress.
- Full **My Progress** functionality (see 4.3).

Free users should see a visible **teaser/paywall prompt** for Pro-gated sections (notably My Progress on the home screen) rather than those sections being hidden entirely — this is a deliberate upsell mechanic, not a placeholder.

### 4.3 Navigation and screens

Bottom tab navigation: **Home, Scan, My Progress, Profile**

**Home screen:**
- Search bar (product/brand/ingredient)
- "Scan a product" CTA → opens Scan tab
- My Progress summary card — live data for Pro users, upgrade prompt for Free users
- Category tile row: **Food, Cosmetics, Supplements, Meal Scanner** (Meal Scanner tile carries a visible "PRO" badge)
- Recent Scans list, pulled from the `scans` table joined to `products`

**Scan screen:**
- Camera view with live barcode detection
- On successful scan: look up the barcode in `products`. If found, navigate to the product detail screen. If not found (the expected common case early on, given the data gap) — route to a "submit this product" flow rather than a dead end, writing into `product_submissions` for later review.

**Product detail screen** (this is the core screen — model its layout directly on the Yuka reference screenshots provided during product discovery):
- Product name, brand, image
- Score out of 100 with a plain-language verdict (e.g., "Bad," "Good") and a color dot
- **Negatives** section, per-100g or per-100mL: each row shows a metric name, a one-line plain-language judgment (e.g., "Too sweet," "Too caloric"), the raw value, and a color-coded dot. Typical fields: Additives (with a count and risk tier), Sugar, Saturates, Salt, Energy.
- **Positives** section, same row format, for fields that score well.
- Additives specifically need a risk tier, not just present/absent — matches `product_additives.risk_level` (no_risk / limited_risk / moderate_risk / high_risk) in the schema.
- Options block: Add to favorites, Food preferences, Delete from history, Scoring method (transparency link explaining the algorithm), Report an issue with this product.
- Recommendations: alternative/similar products, horizontally scrollable.

**My Progress screen**: calorie/macro/weight tracking dashboards, sourced from `diary_entries`, `weight_logs`, and `user_goals`. Pro-only — screen must defensively check subscription status itself (don't rely solely on navigation having gated access, since deep links and back-navigation can reach it directly).

**Profile screen**: account info, current plan (Free/Pro), sign out.

**Auth screens**: standard sign in / sign up against Supabase Auth.

## 5. Technical architecture

### 5.1 Stack and rationale

| Layer | Choice | Why |
|---|---|---|
| Platform | Native mobile, iOS (App Store) + Android (Google Play) | Required — not a web app or PWA. |
| Frontend | React Native + Expo (Expo Router for navigation) | Single codebase for both platforms; Expo avoids most native Xcode/Android Studio config work, which matters given the founder isn't hand-writing native code. |
| Backend | Supabase (Postgres + Auth + Storage, Row Level Security) | Managed — no server to provision or maintain. Free tier is sufficient through MVP. |
| Subscriptions | RevenueCat | Handles App Store/Google Play receipt validation and entitlement logic, which is genuinely painful to hand-build correctly across both platforms solo. |
| Crash/error monitoring | Sentry | Non-negotiable for a solo dev with no QA team — you won't find out about production crashes otherwise. |

This stack is a locked decision from architecture review, not open for casual reconsideration — if you believe there's a strong technical reason to deviate, say so explicitly and explain why before changing anything.

### 5.2 Database schema

The complete schema is in **`se7ty_schema.sql`** (provided alongside this brief) — Postgres/Supabase, with Row Level Security policies included. Treat it as authoritative. Core tables: `profiles`, `products`, `product_nutrition`, `product_additives`, `product_ingredients`, `product_submissions`, `product_reports`, `scans`, `favorites`, `meals`, `meal_items`, `diary_entries`, `weight_logs`, `user_goals`.

Read the schema file directly before writing any backend-touching code — don't infer column names from this summary.

### 5.3 Key architecture decisions (and why)

- **Scores are computed at request time, never stored.** The scoring algorithm (section 4.3, Negatives/Positives) will change as it's refined. Computing from raw `product_nutrition` / `product_additives` data means every product's score updates automatically with an algorithm change — no data migration ever needed. A placeholder implementation exists at `src/utils/scoring.ts` in the scaffold; it is explicitly **not** the real methodology (see "Open decisions," item 2).
- **Subscription entitlement is server-authoritative.** `profiles.subscription_tier` is written **only** by a server-side RevenueCat webhook handler (using the Supabase service role), **never** by the client app directly. Never trust a client-reported "I'm subscribed" flag — that's a standard entitlement-spoofing mistake.
- **Row Level Security is enabled on every table.** Public catalog data (products, nutrition, additives, ingredients) is readable by anyone; everything else (scans, favorites, diary entries, weight logs, submissions) is scoped to `auth.uid()`, so one user's data is unreachable by another even if a client API key leaks. Policies are already written in the schema file — extend this pattern for any new tables rather than inventing a new access model.
- **`product_submissions` is a moderation queue, not a direct write path.** User-submitted products never go live in `products` automatically; promoting a submission should run through a backend function reviewed by an admin, never a direct client-side insert into the public catalog.

## 6. Data strategy — the Egyptian product catalog

This is arguably a bigger challenge than the app code itself, and needs to run in parallel with development, not after it.

**Chosen approach**: bootstrap the catalog from Open Food Facts' open dataset, then let users submit missing products in-app (photo of barcode + label), with manual admin approval via the `product_submissions` queue before anything goes live.

**Strong recommendation carried over from architecture review, not yet formally committed by the founder**: hand-seed roughly 50–100 genuinely common Egyptian staples (major dairy, snack, and beverage brands) before real users are let in. Without this, the app will return "not found" on most early scans, which is a serious first-impression risk for an app whose core pitch is local coverage. This is a data-entry task the founder or their business partner can run in parallel with your development work — flag it back to them if it hasn't happened by the time the Scan flow is testable.

## 7. Current project state

What already exists (provided alongside this brief as a starter scaffold — inspect directly rather than trusting this list to be exhaustive):

- `se7ty_schema.sql` — complete, reviewed, and approved by the founder.
- A project directory skeleton (`app/(auth)/`, `app/(tabs)/`, `app/product/`, `src/services/`, `src/context/`, `src/types/`, `src/constants/`, `src/utils/`) with **only `src/constants/theme.ts` actually populated.**

**Not yet built — this is the bulk of remaining work**: the Supabase client setup, the auth context/provider, the root auth-gated layout, all tab screens (Home, Scan, My Progress, Profile), the product detail screen, sign-in/sign-up screens, the TypeScript types mirroring the schema, and the placeholder scoring utility described in section 5.3. Build these next, in that rough order (Supabase client and auth first, since everything else depends on them).

## 8. Open decisions (need a human call, don't just pick one silently)

1. **Meal Scanner recognition vendor** — not yet chosen. Build the UI and data model now; leave the actual recognition call stubbed and clearly marked until a provider is selected and its cost/accuracy (including on Egyptian/Middle Eastern dishes specifically) is validated against the Pro subscription price.
2. **Real scoring methodology** — the current `calculateScore` stub is a rough placeholder only. The real weighting (how much sugar/additives/saturates should count against each other, and whether that differs across Food vs. Cosmetics vs. Supplements, which don't share a nutrition model) needs a dedicated design pass before this ships to real users. Don't let a placeholder formula quietly become the shipped one.
3. **Arabic search/matching** (e.g., a user searching "زبادي" correctly matching "yogurt") — a real feature gap given the target market, but best solved once there's enough real product data to test against rather than designing it against an empty catalog.

## 9. Known risks to keep in mind

1. **Empty catalog at launch** — see section 6. Product risk, not a coding task, but it affects how you should sequence/test the Scan flow (the "not found → submit" path needs to actually work well, since it'll be hit often early on).
2. **API drift to verify before trusting**: Expo Router had a significant internal rewrite in SDK 56 (moved off React Navigation internals) — the auth-gating pattern (redirecting based on `useSegments()`) is the standard documented approach, but verify it against current Expo Router docs rather than assuming it's unchanged. Similarly, `expo-camera`'s barcode-scanning props (`barcodeScannerSettings`, `onBarcodeScanned`) have shifted across recent SDK releases — confirm the current signature before implementing the Scan screen.
3. **Legal/defamation exposure, scoped down from earlier research**: an earlier version of this project involved independent lab testing and publishing safety findings on named brands, which carries serious defamation/cybercrime risk under Egyptian law (criminal, not just civil) if handled carelessly. **That model has been dropped.** The current Yuka-style, label-data-only scoring is lower risk, but not zero — Yuka itself faced real (ultimately won, after appeal) legal action in France from a meat-industry federation over its nitrite scoring. Worth a lightweight legal review of Se7ty's scoring language and disclaimers before scaling beyond a small beta, even though it doesn't need the heavy lab-testing-era legal protocol (NFSA referral before publishing, right-of-reply windows, etc.) that earlier research focused on.
4. **What's still useful from the earlier lab-testing-era research**: the Egyptian market context (counterfeit supplements, social-media misinformation, regulatory bodies like NFSA/EDA) is still directly relevant to positioning and the Supplements category. The lab-infrastructure research (accredited labs, PFAS/microplastics testing capability) is **not** relevant to the current product and can be disregarded.

## 10. Immediate next steps

1. Scaffold the actual Expo project via `npx create-expo-app@latest` (TypeScript template) if not already done, and merge in the existing directory structure/theme file rather than starting from a blank slate.
2. Build the Supabase client (`src/services/supabase.ts`) and auth context (`src/context/AuthContext.tsx`), wired to the schema's `profiles` table.
3. Build the auth-gated root layout and the four tab screens as functional shells, then layer in real data fetching per section 4.3.
4. Build the product detail screen against the schema's nutrition/additive tables, using the placeholder scoring function, clearly marked as temporary per section 8, item 2.
5. Confirm with the founder before writing the Meal Scanner recognition integration — that's explicitly gated on a vendor decision that hasn't been made yet.
