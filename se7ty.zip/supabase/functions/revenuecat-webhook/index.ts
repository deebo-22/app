// =============================================================================
// RevenueCat → Supabase entitlement sync (Supabase Edge Function, Deno).
//
// This is the ONLY code path that writes profiles.subscription_tier.
//
// Design:
//  - Authenticates the webhook with a shared secret (RevenueCat's "Authorization
//    header value" setting), compared in constant time.
//  - Does NOT trust the event body for entitlement state. Events can arrive
//    late, duplicated, or out of order, and a body is only as trustworthy as
//    the secret. The event is treated as a "something changed for user X"
//    signal; the function then asks RevenueCat's REST API (with the secret API
//    key) for the authoritative current state and writes that.
//
// Deploy (no Supabase JWT on RevenueCat's requests, so JWT verification is off —
// the shared secret replaces it):
//   supabase functions deploy revenuecat-webhook --no-verify-jwt
//   supabase secrets set REVENUECAT_WEBHOOK_AUTH=<long random string> \
//                        REVENUECAT_SECRET_API_KEY=<sk_...> \
//                        REVENUECAT_ENTITLEMENT_ID=pro
// SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are injected automatically.
// =============================================================================
import { createClient } from 'jsr:@supabase/supabase-js@2';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function env(name: string): string {
  const v = Deno.env.get(name);
  if (!v) throw new Error(`Missing env ${name}`);
  return v;
}

function timingSafeEqual(a: string, b: string): boolean {
  const enc = new TextEncoder();
  const x = enc.encode(a);
  const y = enc.encode(b);
  let diff = x.length ^ y.length;
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    diff |= (x[i] ?? 0) ^ (y[i] ?? 0);
  }
  return diff === 0;
}

const supabase = createClient(env('SUPABASE_URL'), env('SUPABASE_SERVICE_ROLE_KEY'), {
  auth: { persistSession: false },
});

async function syncUser(appUserId: string) {
  // Only our Supabase user ids are valid (the app calls Purchases.configure with
  // the Supabase user id). Skip RevenueCat anonymous ids and anything else.
  if (!UUID_RE.test(appUserId)) return;

  const res = await fetch(
    `https://api.revenuecat.com/v1/subscribers/${encodeURIComponent(appUserId)}`,
    { headers: { Authorization: `Bearer ${env('REVENUECAT_SECRET_API_KEY')}` } },
  );
  if (!res.ok) throw new Error(`RevenueCat API ${res.status}`);
  const body = await res.json();

  const entitlementId = Deno.env.get('REVENUECAT_ENTITLEMENT_ID') ?? 'pro';
  const ent = body?.subscriber?.entitlements?.[entitlementId];
  const expires: string | null = ent?.expires_date ?? null; // null = lifetime
  const active = !!ent && (expires === null || new Date(expires).getTime() > Date.now());

  const { error } = await supabase
    .from('profiles')
    .update({
      subscription_tier: active ? 'pro' : 'free',
      subscription_expires_at: active ? expires : null,
      revenuecat_app_user_id: appUserId,
    })
    .eq('id', appUserId);
  if (error) throw error;
}

Deno.serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });

  const auth = req.headers.get('Authorization') ?? '';
  if (!timingSafeEqual(auth, env('REVENUECAT_WEBHOOK_AUTH'))) {
    return new Response('Unauthorized', { status: 401 });
  }

  let payload: any;
  try {
    payload = await req.json();
  } catch {
    return new Response('Bad request', { status: 400 });
  }

  const event = payload?.event ?? {};
  const ids = new Set<string>();
  if (typeof event.app_user_id === 'string') ids.add(event.app_user_id);
  if (typeof event.original_app_user_id === 'string') ids.add(event.original_app_user_id);
  // TRANSFER events move a purchase between users — resync both sides.
  for (const id of [...(event.transferred_from ?? []), ...(event.transferred_to ?? [])]) {
    if (typeof id === 'string') ids.add(id);
  }

  try {
    for (const id of ids) await syncUser(id);
  } catch (e) {
    console.error('sync failed', e);
    // Non-2xx makes RevenueCat retry later.
    return new Response('Sync failed', { status: 500 });
  }
  return new Response('ok', { status: 200 });
});
