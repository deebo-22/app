-- =============================================================================
-- Se7ty — 0002: security hardening + profile bootstrap
-- Run AFTER 0001_initial_schema.sql.
-- =============================================================================
-- Fixes found while building the app against 0001:
--
--  1. ENTITLEMENT SPOOFING (critical). "profiles_update_own" lets a user update
--     ANY column of their own row — including subscription_tier. Anyone with the
--     public anon key + their own login could run
--        update profiles set subscription_tier = 'pro' where id = auth.uid();
--     RLS is row-level only, so the fix is column-level privileges: clients may
--     update display_name / preferred_language and nothing else. The RevenueCat
--     webhook uses the service role, which bypasses these grants.
--
--  2. MODERATION BYPASS. The insert policies on product_submissions /
--     product_reports allow a client to set status='approved', reviewed_by,
--     reviewed_at, or resolved=true on insert. Column-level insert grants limit
--     clients to the fields they legitimately provide.
--
--  3. MISSING PROFILE ROW. Nothing created a profiles row on sign-up, and there
--     is (correctly) no client insert policy. A security-definer trigger on
--     auth.users now creates it.
--
--  4. updated_at columns were never maintained — added triggers.
--
--  5. Oversized-payload guard on product_submissions.raw_data.
-- =============================================================================

-- 1. Profiles: column-level update privileges -------------------------------
revoke update on table public.profiles from anon, authenticated;
grant update (display_name, preferred_language) on table public.profiles to authenticated;

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles
  for update using (auth.uid() = id) with check (auth.uid() = id);

alter table public.profiles
  add constraint profiles_display_name_len check (display_name is null or char_length(display_name) <= 80);

-- 2. Submissions / reports: column-level insert privileges -------------------
revoke insert, update, delete on table public.product_submissions from anon, authenticated;
grant insert (submitted_by, barcode, raw_data) on table public.product_submissions to authenticated;

revoke insert, update, delete on table public.product_reports from anon, authenticated;
grant insert (product_id, reported_by, issue_description) on table public.product_reports to authenticated;

alter table public.product_submissions
  add constraint submissions_barcode_format check (barcode ~ '^[0-9]{6,14}$'),
  add constraint submissions_raw_data_size check (pg_column_size(raw_data) < 32000);

alter table public.product_reports
  add constraint reports_description_len check (char_length(issue_description) between 3 and 2000);

-- Catalog tables: make it explicit that clients can never write them.
revoke insert, update, delete on table
  public.products, public.product_nutrition, public.product_additives, public.product_ingredients
  from anon, authenticated;

-- 3. Auto-create profile on sign-up ------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  lang text := new.raw_user_meta_data ->> 'preferred_language';
begin
  insert into public.profiles (id, display_name, preferred_language)
  values (
    new.id,
    left(nullif(trim(new.raw_user_meta_data ->> 'display_name'), ''), 80),
    case when lang in ('ar', 'en') then lang else 'ar' end
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Backfill any users created before this migration.
insert into public.profiles (id)
select id from auth.users
on conflict (id) do nothing;

-- 4. updated_at maintenance --------------------------------------------------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();

drop trigger if exists products_set_updated_at on public.products;
create trigger products_set_updated_at before update on public.products
  for each row execute function public.set_updated_at();

drop trigger if exists user_goals_set_updated_at on public.user_goals;
create trigger user_goals_set_updated_at before update on public.user_goals
  for each row execute function public.set_updated_at();
