-- =============================================================================
-- Se7ty — Core Database Schema (Draft v1)
-- Target: Supabase (Postgres + Auth + RLS)
-- Phase: 3 — Project Foundation
-- =============================================================================
-- Design principles for this draft:
--   1. Scores are computed at request time from nutrition/additive data, never
--      stored — so refining the scoring algorithm later never requires a
--      data migration across every product.
--   2. Subscription status is written ONLY by a server-side RevenueCat
--      webhook (via Supabase service role), never by the client app. The
--      client must never be trusted to self-report entitlement.
--   3. Every table a single user "owns" (diary entries, weight logs,
--      favorites, scan history) has Row Level Security scoped to auth.uid(),
--      so one user's data is unreachable by another user even if an API key
--      leaks client-side.
--   4. product_submissions is the crowdsourcing intake queue for Option (a):
--      users submit barcode + data, nothing goes live until reviewed.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- ENUM TYPES
-- ---------------------------------------------------------------------------

create type product_category as enum ('food', 'cosmetics', 'supplements');
create type additive_risk as enum ('no_risk', 'limited_risk', 'moderate_risk', 'high_risk');
create type submission_status as enum ('pending', 'approved', 'rejected');
create type subscription_tier as enum ('free', 'pro');
create type scan_source as enum ('barcode', 'meal_photo');
create type diary_meal_type as enum ('breakfast', 'lunch', 'dinner', 'snack');

-- ---------------------------------------------------------------------------
-- PROFILES
-- Extends Supabase's built-in auth.users with app-specific fields.
-- subscription_tier / subscription_expires_at are the ONLY source of truth
-- for entitlement — written exclusively by the RevenueCat webhook handler,
-- never by the client.
-- ---------------------------------------------------------------------------

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  preferred_language text not null default 'ar' check (preferred_language in ('ar', 'en')),
  subscription_tier subscription_tier not null default 'free',
  subscription_expires_at timestamptz,
  revenuecat_app_user_id text unique,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- PRODUCTS
-- Core catalog entry. Covers all three categories (food, cosmetics,
-- supplements) — nutrition-specific fields live in product_nutrition since
-- cosmetics won't have them.
-- ---------------------------------------------------------------------------

create table products (
  id uuid primary key default gen_random_uuid(),
  barcode text unique not null,
  category product_category not null,
  name text not null,
  name_ar text,
  brand text,
  image_url text,
  serving_unit text not null default '100g' check (serving_unit in ('100g', '100ml')),
  source text not null default 'seed' check (source in ('seed', 'open_food_facts', 'user_submitted')),
  verified boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_products_barcode on products(barcode);
create index idx_products_category on products(category);

-- ---------------------------------------------------------------------------
-- PRODUCT_NUTRITION
-- 1:1 with products, but kept separate so cosmetics rows in `products`
-- don't carry a wall of null nutrition columns.
-- ---------------------------------------------------------------------------

create table product_nutrition (
  product_id uuid primary key references products(id) on delete cascade,
  energy_kcal numeric,
  sugar_g numeric,
  saturates_g numeric,
  salt_g numeric,
  protein_g numeric,
  carbs_g numeric,
  fiber_g numeric
);

-- ---------------------------------------------------------------------------
-- PRODUCT_ADDITIVES
-- One row per additive found in a product, each with its own risk tier —
-- matches the "Additives: 10, limited risk" style breakdown from the
-- reference UI.
-- ---------------------------------------------------------------------------

create table product_additives (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references products(id) on delete cascade,
  code text not null,          -- e.g. 'E150d'
  name text not null,
  risk_level additive_risk not null default 'no_risk'
);

create index idx_product_additives_product on product_additives(product_id);

-- ---------------------------------------------------------------------------
-- PRODUCT_INGREDIENTS
-- Ordered ingredient list as printed on the label.
-- ---------------------------------------------------------------------------

create table product_ingredients (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references products(id) on delete cascade,
  ingredient_name text not null,
  sort_order int not null default 0
);

create index idx_product_ingredients_product on product_ingredients(product_id);

-- ---------------------------------------------------------------------------
-- PRODUCT_SUBMISSIONS
-- Crowdsourcing intake queue (Option a). A user submits a barcode + raw
-- data; nothing here is live in `products` until an admin approves it and
-- a backend job copies it over.
-- ---------------------------------------------------------------------------

create table product_submissions (
  id uuid primary key default gen_random_uuid(),
  submitted_by uuid references auth.users(id) on delete set null,
  barcode text not null,
  raw_data jsonb not null,     -- name, brand, category, nutrition, ingredients, photo urls
  status submission_status not null default 'pending',
  reviewed_by uuid references auth.users(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create index idx_product_submissions_status on product_submissions(status);

-- ---------------------------------------------------------------------------
-- PRODUCT_REPORTS
-- "An issue with this product?" flagging, per the reference UI.
-- ---------------------------------------------------------------------------

create table product_reports (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references products(id) on delete cascade,
  reported_by uuid references auth.users(id) on delete set null,
  issue_description text not null,
  resolved boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- SCANS
-- Scan history. Powers the "Recent Scans" / History screen.
-- ---------------------------------------------------------------------------

create table scans (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id uuid not null references products(id) on delete cascade,
  source scan_source not null default 'barcode',
  scanned_at timestamptz not null default now()
);

create index idx_scans_user on scans(user_id, scanned_at desc);

-- ---------------------------------------------------------------------------
-- FAVORITES
-- ---------------------------------------------------------------------------

create table favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id uuid not null references products(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, product_id)
);

-- ---------------------------------------------------------------------------
-- MEALS / MEAL_ITEMS
-- Data model for Meal Scanner (Pro). The recognition call itself is a
-- stubbed function for now — this schema just gives the feature a home so
-- the UI has something real to read/write once the vendor is chosen.
-- ---------------------------------------------------------------------------

create table meals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  photo_url text,
  status text not null default 'pending' check (status in ('pending', 'processed', 'failed')),
  total_calories numeric,
  total_protein_g numeric,
  total_carbs_g numeric,
  total_fat_g numeric,
  created_at timestamptz not null default now()
);

create table meal_items (
  id uuid primary key default gen_random_uuid(),
  meal_id uuid not null references meals(id) on delete cascade,
  food_name text not null,
  calories numeric,
  protein_g numeric,
  carbs_g numeric,
  fat_g numeric,
  confidence numeric   -- recognition confidence score, once a vendor is wired up
);

create index idx_meals_user on meals(user_id, created_at desc);

-- ---------------------------------------------------------------------------
-- DIARY_ENTRIES
-- The calorie/macro tracking log (My Progress). Can reference a scanned
-- product OR a recognized meal OR be a manual entry — exactly one of
-- product_id / meal_id is set, or neither for a manual entry.
-- ---------------------------------------------------------------------------

create table diary_entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  logged_date date not null default current_date,
  meal_type diary_meal_type not null,
  product_id uuid references products(id),
  meal_id uuid references meals(id),
  manual_label text,
  calories numeric not null,
  protein_g numeric,
  carbs_g numeric,
  fat_g numeric,
  created_at timestamptz not null default now(),
  constraint one_source_check check (
    (product_id is not null)::int + (meal_id is not null)::int + (manual_label is not null)::int = 1
  )
);

create index idx_diary_entries_user_date on diary_entries(user_id, logged_date);

-- ---------------------------------------------------------------------------
-- WEIGHT_LOGS
-- ---------------------------------------------------------------------------

create table weight_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  logged_date date not null default current_date,
  weight_kg numeric not null,
  created_at timestamptz not null default now(),
  unique (user_id, logged_date)
);

-- ---------------------------------------------------------------------------
-- USER_GOALS
-- Targets that power the My Progress rings/trends.
-- ---------------------------------------------------------------------------

create table user_goals (
  user_id uuid primary key references auth.users(id) on delete cascade,
  daily_calorie_goal numeric,
  protein_goal_g numeric,
  carbs_goal_g numeric,
  fat_goal_g numeric,
  target_weight_kg numeric,
  updated_at timestamptz not null default now()
);

-- =============================================================================
-- ROW LEVEL SECURITY
-- Public catalog data (products, nutrition, additives, ingredients) is
-- readable by anyone. Everything else is scoped to auth.uid() so one
-- user's data is unreachable by another, even with a leaked anon key.
-- product_submissions review/approval happens via the Supabase service
-- role in a backend function, not via RLS — regular users can insert but
-- not read others' submissions or self-approve.
-- =============================================================================

alter table profiles enable row level security;
alter table products enable row level security;
alter table product_nutrition enable row level security;
alter table product_additives enable row level security;
alter table product_ingredients enable row level security;
alter table product_submissions enable row level security;
alter table product_reports enable row level security;
alter table scans enable row level security;
alter table favorites enable row level security;
alter table meals enable row level security;
alter table meal_items enable row level security;
alter table diary_entries enable row level security;
alter table weight_logs enable row level security;
alter table user_goals enable row level security;

-- Profiles: users can read/update only their own row.
create policy "profiles_select_own" on profiles for select using (auth.uid() = id);
create policy "profiles_update_own" on profiles for update using (auth.uid() = id);

-- Public catalog: readable by any authenticated user, writable only via
-- service role (backend), never directly by the client.
create policy "products_select_all" on products for select using (true);
create policy "product_nutrition_select_all" on product_nutrition for select using (true);
create policy "product_additives_select_all" on product_additives for select using (true);
create policy "product_ingredients_select_all" on product_ingredients for select using (true);

-- Submissions: any authenticated user can submit; users can see only their
-- own submissions (status included, so they can track what happened to it).
create policy "submissions_insert_own" on product_submissions for insert with check (auth.uid() = submitted_by);
create policy "submissions_select_own" on product_submissions for select using (auth.uid() = submitted_by);

-- Reports: any authenticated user can file one; no read policy for regular
-- users (only the backend/service role needs to review these).
create policy "reports_insert_own" on product_reports for insert with check (auth.uid() = reported_by);

-- User-owned data: strict owner-only access.
create policy "scans_owner_all" on scans for all using (auth.uid() = user_id);
create policy "favorites_owner_all" on favorites for all using (auth.uid() = user_id);
create policy "meals_owner_all" on meals for all using (auth.uid() = user_id);
create policy "diary_owner_all" on diary_entries for all using (auth.uid() = user_id);
create policy "weight_owner_all" on weight_logs for all using (auth.uid() = user_id);
create policy "goals_owner_all" on user_goals for all using (auth.uid() = user_id);

-- meal_items has no direct user_id — scope through its parent meal.
create policy "meal_items_owner_all" on meal_items for all using (
  exists (select 1 from meals where meals.id = meal_items.meal_id and meals.user_id = auth.uid())
);
