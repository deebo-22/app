-- =============================================================================
-- DEVELOPMENT TEST DATA ONLY — DO NOT LOAD INTO PRODUCTION.
-- =============================================================================
-- Fictional products with made-up barcodes and made-up values, so the Scan →
-- Product flow can be tested before the real catalog exists. Names are prefixed
-- "[TEST]" so they can never be mistaken for real brand data (publishing
-- invented nutrition values under a real brand's name is a legal risk — brief §9.3).
--
-- Test by typing these barcodes into "Enter barcode manually" on the Scan tab:
--   0000000000017  → "good" dairy-style product
--   0000000000024  → "bad" sugary snack
--   0000000000031  → cosmetic (no nutrition → additives-only/unscored)
--   0000000000048  → unknown barcode → exercises the "submit this product" flow
--                    (intentionally NOT inserted)
-- =============================================================================

insert into products (id, barcode, category, name, name_ar, brand, serving_unit, source, verified) values
  ('00000000-0000-0000-0000-000000000001', '0000000000017', 'food', '[TEST] Plain Yogurt', '[تجربة] زبادي سادة', 'Test Dairy', '100g', 'seed', true),
  ('00000000-0000-0000-0000-000000000002', '0000000000024', 'food', '[TEST] Fruit Gummies', '[تجربة] حلوى فواكه', 'Test Sweets', '100g', 'seed', true),
  ('00000000-0000-0000-0000-000000000003', '0000000000031', 'cosmetics', '[TEST] Moisturizing Cream', '[تجربة] كريم مرطب', 'Test Care', '100ml', 'seed', false)
on conflict (barcode) do nothing;

insert into product_nutrition (product_id, energy_kcal, sugar_g, saturates_g, salt_g, protein_g, carbs_g, fiber_g) values
  ('00000000-0000-0000-0000-000000000001', 62, 4.2, 1.1, 0.12, 3.8, 4.5, 0),
  ('00000000-0000-0000-0000-000000000002', 355, 61.4, 0.1, 0.23, 4.1, 84, 0)
on conflict (product_id) do nothing;

insert into product_additives (product_id, code, name, risk_level) values
  ('00000000-0000-0000-0000-000000000002', 'E330', 'Citric acid', 'no_risk'),
  ('00000000-0000-0000-0000-000000000002', 'E422', 'Glycerol', 'limited_risk'),
  ('00000000-0000-0000-0000-000000000002', 'E150d', 'Sulphite ammonia caramel', 'moderate_risk'),
  ('00000000-0000-0000-0000-000000000003', 'E218', 'Methylparaben', 'moderate_risk');

insert into product_ingredients (product_id, ingredient_name, sort_order) values
  ('00000000-0000-0000-0000-000000000001', 'Milk', 1),
  ('00000000-0000-0000-0000-000000000001', 'Live cultures', 2),
  ('00000000-0000-0000-0000-000000000002', 'Glucose syrup', 1),
  ('00000000-0000-0000-0000-000000000002', 'Sugar', 2),
  ('00000000-0000-0000-0000-000000000002', 'Fruit juice from concentrate (8%)', 3),
  ('00000000-0000-0000-0000-000000000003', 'Aqua', 1),
  ('00000000-0000-0000-0000-000000000003', 'Glycerin', 2);
