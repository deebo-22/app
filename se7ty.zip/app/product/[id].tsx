import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { Screen } from '@/src/components/Screen';
import { NutrientRow } from '@/src/components/NutrientRow';
import { ProGate } from '@/src/components/ProGate';
import { ProductImage, productDisplayName } from '@/src/components/ProductRow';
import { ScoreHeader, ScoreRing, VerdictPill } from '@/src/components/Score';
import { BackChevron, Button, CircleButton, ErrorState, Loading, TextField } from '@/src/components/ui';
import { colors, radius, spacing } from '@/src/constants/theme';
import { useAuth } from '@/src/context/AuthContext';
import { useI18n } from '@/src/context/LanguageContext';
import { getProductDetail, getRecommendations } from '@/src/services/products';
import { isFavorite, reportProductIssue, setFavorite } from '@/src/services/catalog';
import { deleteProductFromHistory } from '@/src/services/scans';
import { captureError } from '@/src/services/monitoring';
import type { ProductDetail } from '@/src/types/database';
import { calculateScore, SCORING_IS_PLACEHOLDER } from '@/src/utils/scoring';

export default function ProductScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { t, language } = useI18n();
  const { user, isPro } = useAuth();
  const [product, setProduct] = useState<ProductDetail | null>(null);
  const [status, setStatus] = useState<'loading' | 'ready' | 'notFound' | 'error'>('loading');
  const [favorite, setFav] = useState(false);
  const [recs, setRecs] = useState<ProductDetail[]>([]);
  const [reportOpen, setReportOpen] = useState(false);

  const load = useCallback(async () => {
    if (!id) return;
    setStatus('loading');
    try {
      const p = await getProductDetail(id);
      if (!p) return setStatus('notFound');
      setProduct(p);
      setStatus('ready');
      if (user) isFavorite(user.id, p.id).then(setFav).catch(captureError);
      getRecommendations(p).then(setRecs).catch(captureError);
    } catch (e) {
      captureError(e);
      setStatus('error');
    }
  }, [id, user]);

  useEffect(() => {
    load();
  }, [load]);

  const result = useMemo(() => (product ? calculateScore(product) : null), [product]);

  if (status === 'loading') return <Screen scroll={false}><Loading /></Screen>;
  if (status === 'error') return <Screen scroll={false}><ErrorState onRetry={load} /></Screen>;
  if (status === 'notFound' || !product || !result) {
    return (
      <Screen scroll={false}>
        <ErrorState message={t('product.notFound')} />
      </Screen>
    );
  }

  const name = productDisplayName(product, language);
  const unitLabel = product.serving_unit === '100ml' ? t('common.per100ml') : t('common.per100g');

  async function toggleFavorite() {
    if (!user || !product) return;
    const next = !favorite;
    setFav(next); // optimistic
    try {
      await setFavorite(user.id, product.id, next);
    } catch (e) {
      setFav(!next);
      captureError(e);
    }
  }

  async function removeFromHistory() {
    if (!product) return;
    try {
      await deleteProductFromHistory(product.id);
      Alert.alert(t('product.deletedHistory'));
      router.back();
    } catch (e) {
      captureError(e);
      Alert.alert(t('common.error'));
    }
  }

  function share() {
    Share.share({
      message:
        result?.score != null ? t('product.share', { name, score: result.score }) : name,
    }).catch(() => {});
  }

  return (
    <Screen>
      {/* Top bar */}
      <View style={styles.topBar}>
        <CircleButton onPress={() => router.back()} label={t('common.back')}>
          <BackChevron size={28} />
        </CircleButton>
        <CircleButton onPress={share} label="Share">
          <Feather name="share" size={22} color={colors.text} />
        </CircleButton>
      </View>

      {/* Header */}
      <View style={styles.header}>
        <ProductImage uri={product.image_url} size={120} category={product.category} />
        <View style={{ flex: 1, gap: spacing.sm }}>
          <Text style={styles.name}>{name}</Text>
          {product.brand ? <Text style={styles.brand}>{product.brand}</Text> : null}
          <View style={{ marginTop: spacing.sm }}>
            {result.score != null && result.verdict ? (
              <ScoreHeader score={result.score} verdict={result.verdict} />
            ) : (
              <Text style={styles.brand}>{t('product.noScore')}</Text>
            )}
          </View>
        </View>
      </View>

      {!product.verified && (
        <View style={styles.notice}>
          <Feather name="users" size={14} color={colors.textMuted} />
          <Text style={styles.noticeText}>{t('product.unverified')}</Text>
        </View>
      )}
      {SCORING_IS_PLACEHOLDER && result.score != null && (
        <Pressable style={styles.notice} onPress={() => router.push('/scoring-method')}>
          <Feather name="info" size={14} color={colors.textMuted} />
          <Text style={[styles.noticeText, { textDecorationLine: 'underline' }]}>{t('product.betaScore')}</Text>
        </Pressable>
      )}

      {/* Breakdown — Pro only; Free users get the score above plus this teaser */}
      {isPro ? (
        <>
          {result.negatives.length > 0 && (
            <Section title={t('product.negatives')} right={unitLabel}>
              {result.negatives.map((a, i) => (
                <NutrientRow
                  key={a.key}
                  assessment={a}
                  additives={a.key === 'additives' ? product.additives : undefined}
                  isLast={i === result.negatives.length - 1}
                />
              ))}
            </Section>
          )}
          {result.positives.length > 0 && (
            <Section title={t('product.positives')} right={unitLabel}>
              {result.positives.map((a, i) => (
                <NutrientRow
                  key={a.key}
                  assessment={a}
                  additives={a.key === 'additives' ? product.additives : undefined}
                  isLast={i === result.positives.length - 1}
                />
              ))}
            </Section>
          )}
          {product.ingredients.length > 0 && (
            <Section title={t('product.ingredients')}>
              <Text style={[styles.ingredients, { paddingVertical: spacing.md }]}>
                {product.ingredients.map((i) => i.ingredient_name).join(', ')}
              </Text>
            </Section>
          )}
        </>
      ) : (
        <View style={{ marginTop: spacing.xxl }}>
          <ProGate title={t('product.unlockTitle')} body={t('product.unlockBody')} />
        </View>
      )}

      {/* Recommendations */}
      <Section title={t('product.recommendations')} plain>
        {recs.length === 0 ? (
          <Text style={styles.brand}>{t('product.noRecommendations')}</Text>
        ) : (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: spacing.md }}>
            {recs.map((r) => {
              const s = calculateScore(r);
              return (
                <Pressable key={r.id} style={styles.rec} onPress={() => router.push(`/product/${r.id}`)}>
                  <ProductImage uri={r.image_url} size={124} category={r.category} />
                  <Text style={styles.recName} numberOfLines={2}>
                    {productDisplayName(r, language)}
                  </Text>
                  {r.brand ? <Text style={styles.recBrand} numberOfLines={1}>{r.brand}</Text> : null}
                  <View style={styles.recScore}>
                    {s.verdict && <VerdictPill verdict={s.verdict} />}
                    <ScoreRing score={s.score} verdict={s.verdict} size={40} />
                  </View>
                </Pressable>
              );
            })}
          </ScrollView>
        )}
      </Section>

      {/* Options */}
      <Section title={t('product.options')}>
        <OptionRow
          icon="heart"
          label={favorite ? t('product.removeFavorite') : t('product.addFavorite')}
          onPress={toggleFavorite}
          active={favorite}
        />
        <OptionRow
          icon="sliders"
          label={t('product.foodPreferences')}
          onPress={() => Alert.alert(t('product.foodPreferences'), t('common.comingSoon'))}
        />
        <OptionRow icon="trash-2" label={t('product.deleteHistory')} onPress={removeFromHistory} />
        <OptionRow icon="info" label={t('product.scoringMethod')} onPress={() => router.push('/scoring-method')} />
        <OptionRow icon="flag" label={t('product.reportIssue')} onPress={() => setReportOpen(true)} last />
      </Section>

      <ReportModal
        visible={reportOpen}
        onClose={() => setReportOpen(false)}
        onSubmit={async (text) => {
          if (!user) return;
          await reportProductIssue(user.id, product.id, text);
          setReportOpen(false);
          Alert.alert(t('product.reportSent'));
        }}
      />
    </Screen>
  );
}

function Section({
  title,
  right,
  plain,
  children,
}: {
  title: string;
  right?: string;
  /** Skip the white card wrapper (for content that brings its own cards). */
  plain?: boolean;
  children: React.ReactNode;
}) {
  return (
    <View style={{ marginTop: spacing.xxxl }}>
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>{title}</Text>
        {right ? <Text style={styles.sectionRight}>{right}</Text> : null}
      </View>
      {plain ? children : <View style={styles.sectionCard}>{children}</View>}
    </View>
  );
}

function OptionRow({
  icon,
  label,
  onPress,
  active,
  last,
}: {
  icon: React.ComponentProps<typeof Feather>['name'];
  label: string;
  onPress: () => void;
  active?: boolean;
  last?: boolean;
}) {
  return (
    <Pressable onPress={onPress} style={[styles.option, !last && styles.optionDivider]} accessibilityRole="button">
      <Feather name={icon} size={22} color={active ? colors.judgment.bad : colors.textMuted} />
      <Text style={styles.optionText}>{label}</Text>
    </Pressable>
  );
}

function ReportModal({
  visible,
  onClose,
  onSubmit,
}: {
  visible: boolean;
  onClose: () => void;
  onSubmit: (text: string) => Promise<void>;
}) {
  const { t, isRTL } = useI18n();
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.backdrop}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
        <View style={[styles.sheet, { direction: isRTL ? 'rtl' : 'ltr' }]}>
          <Text style={styles.sectionTitle}>{t('product.reportTitle')}</Text>
          <TextField
            value={text}
            onChangeText={setText}
            placeholder={t('product.reportPlaceholder')}
            multiline
            maxLength={2000}
            style={{ minHeight: 120, textAlignVertical: 'top' }}
          />
          <Button
            title={t('product.reportSend')}
            loading={sending}
            disabled={text.trim().length < 3}
            onPress={async () => {
              setSending(true);
              try {
                await onSubmit(text);
                setText('');
              } catch (e) {
                captureError(e);
                Alert.alert(t('common.error'));
              } finally {
                setSending(false);
              }
            }}
          />
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  topBar: { flexDirection: 'row', justifyContent: 'space-between', marginTop: spacing.md, marginBottom: spacing.xl },
  header: { flexDirection: 'row', gap: spacing.xl, alignItems: 'flex-start' },
  name: { fontSize: 22, fontWeight: '800', color: colors.text },
  brand: { fontSize: 15, color: colors.primaryText },
  notice: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginTop: spacing.lg,
  },
  noticeText: { flex: 1, fontSize: 13, color: colors.textMuted },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  sectionTitle: { fontSize: 22, fontWeight: '800', color: colors.text },
  sectionRight: { fontSize: 15, color: colors.textSubtle },
  sectionCard: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.xs,
  },
  ingredients: { fontSize: 15, lineHeight: 22, color: colors.textBody },
  rec: {
    width: 152,
    gap: 6,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
  },
  recScore: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 4 },
  recName: { fontSize: 15, fontWeight: '600', color: colors.textBody },
  recBrand: { fontSize: 13, color: colors.textMuted },
  option: { flexDirection: 'row', alignItems: 'center', gap: spacing.lg, paddingVertical: spacing.lg },
  optionDivider: { borderBottomWidth: 1, borderBottomColor: colors.divider },
  optionText: { fontSize: 16, color: colors.textBody },
  backdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.35)' },
  sheet: {
    backgroundColor: colors.background,
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    padding: spacing.xxl,
    paddingBottom: spacing.xxxl + spacing.lg,
    gap: spacing.lg,
  },
});
