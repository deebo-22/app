import React, { useCallback, useState } from 'react';
import {
  Alert,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useFocusEffect } from 'expo-router';
import Svg, { Circle, Polyline } from 'react-native-svg';
import { Screen } from '@/src/components/Screen';
import { ProGate } from '@/src/components/ProGate';
import { Ring } from '@/src/components/Score';
import { AppHeader, Button, Card, Chip, TextField } from '@/src/components/ui';
import { colors, radius, spacing } from '@/src/constants/theme';
import { useAuth } from '@/src/context/AuthContext';
import { useI18n } from '@/src/context/LanguageContext';
import type { TKey } from '@/src/i18n/strings';
import {
  addDiaryEntry,
  deleteDiaryEntry,
  getDiaryForDate,
  getGoals,
  getWeightLogs,
  logWeight,
  saveGoals,
  sumDiary,
} from '@/src/services/progress';
import { captureError } from '@/src/services/monitoring';
import type { DiaryEntry, DiaryMealType, UserGoals, WeightLog } from '@/src/types/database';
import { parseNumber } from '@/src/utils/date';

const MEAL_TYPES: DiaryMealType[] = ['breakfast', 'lunch', 'dinner', 'snack'];

export default function Progress() {
  const { t } = useI18n();
  const { isPro } = useAuth();

  // Defensive Pro check on the screen itself (brief §4.3): deep links and
  // back-navigation can land here without passing through any gated button.
  if (!isPro) {
    return (
      <Screen>
        <AppHeader />
        <Text style={styles.title}>{t('progress.title')}</Text>
        <Text style={styles.subtitle}>{t('progress.subtitle')}</Text>
        <ProGate title={t('progress.unlockTitle')} body={t('progress.unlockBody')} />
      </Screen>
    );
  }
  return <ProgressDashboard />;
}

function ProgressDashboard() {
  const { t } = useI18n();
  const { user } = useAuth();
  const [diary, setDiary] = useState<DiaryEntry[]>([]);
  const [goals, setGoals] = useState<UserGoals | null>(null);
  const [weights, setWeights] = useState<WeightLog[]>([]);
  const [modal, setModal] = useState<'entry' | 'weight' | 'goals' | null>(null);

  const load = useCallback(async () => {
    if (!user) return;
    try {
      const [d, g, w] = await Promise.all([getDiaryForDate(user.id), getGoals(user.id), getWeightLogs(user.id)]);
      setDiary(d);
      setGoals(g);
      setWeights(w);
    } catch (e) {
      captureError(e);
    }
  }, [user]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load]),
  );

  const totals = sumDiary(diary);
  const calGoal = goals?.daily_calorie_goal ?? null;
  const remaining = calGoal != null ? Math.round(calGoal - totals.calories) : null;
  const latest = weights[weights.length - 1];

  return (
    <Screen>
      <AppHeader />
      <View style={styles.titleRow}>
        <Text style={[styles.title, { marginTop: 0, marginBottom: 0 }]}>{t('progress.title')}</Text>
        <Pressable onPress={() => setModal('goals')} hitSlop={8} style={styles.goalsBtn}>
          <Feather name="target" size={16} color={colors.primary} />
          <Text style={styles.goalsBtnText}>{t('progress.editGoals')}</Text>
        </Pressable>
      </View>

      {/* Calories */}
      <Card style={styles.caloriesCard}>
        <Ring
          percent={calGoal ? (totals.calories / calGoal) * 100 : 0}
          size={150}
          stroke={12}
          color={remaining != null && remaining < 0 ? colors.judgment.bad : colors.primary}
        >
          <Text style={styles.ringBig}>{remaining != null ? Math.abs(remaining) : Math.round(totals.calories)}</Text>
          <Text style={styles.ringSmall}>
            {remaining == null ? t('common.kcal') : remaining >= 0 ? t('progress.left') : t('progress.over')}
          </Text>
        </Ring>
        <View style={{ flex: 1, gap: spacing.md }}>
          <Stat label={t('progress.consumed')} value={`${Math.round(totals.calories)} ${t('common.kcal')}`} />
          {calGoal ? (
            <Stat label={t('progress.goal')} value={`${calGoal} ${t('common.kcal')}`} />
          ) : (
            <Pressable onPress={() => setModal('goals')}>
              <Text style={styles.link}>{t('progress.noGoal')}</Text>
            </Pressable>
          )}
        </View>
      </Card>

      {/* Macros */}
      <Card style={{ marginTop: spacing.md, gap: spacing.lg }}>
        <MacroBar label={t('progress.protein')} value={totals.protein} goal={goals?.protein_goal_g} color="#4E8FD6" />
        <MacroBar label={t('progress.carbs')} value={totals.carbs} goal={goals?.carbs_goal_g} color={colors.judgment.poor} />
        <MacroBar label={t('progress.fat')} value={totals.fat} goal={goals?.fat_goal_g} color="#D46A8C" />
      </Card>

      {/* Diary */}
      <View style={styles.sectionRow}>
        <Text style={styles.section}>{t('progress.diary')}</Text>
        <Pressable onPress={() => setModal('entry')} style={styles.addBtn} accessibilityRole="button">
          <Feather name="plus" size={18} color={colors.textOnPrimary} />
          <Text style={styles.addBtnText}>{t('progress.addEntry')}</Text>
        </Pressable>
      </View>
      {diary.length === 0 ? (
        <Text style={styles.muted}>{t('progress.noEntries')}</Text>
      ) : (
        MEAL_TYPES.filter((m) => diary.some((d) => d.meal_type === m)).map((m) => (
          <View key={m} style={{ marginBottom: spacing.md }}>
            <Text style={styles.mealType}>{t(`meal.${m}`)}</Text>
            {diary
              .filter((d) => d.meal_type === m)
              .map((d) => (
                <View key={d.id} style={styles.entry}>
                  <Text style={styles.entryLabel} numberOfLines={1}>
                    {d.manual_label ?? (d.meal_id ? t('mealScan.title') : '—')}
                  </Text>
                  <Text style={styles.entryKcal}>
                    {Math.round(d.calories)} {t('common.kcal')}
                  </Text>
                  <Pressable
                    hitSlop={8}
                    onPress={async () => {
                      try {
                        await deleteDiaryEntry(d.id);
                        load();
                      } catch (e) {
                        captureError(e);
                      }
                    }}
                  >
                    <Feather name="x" size={18} color={colors.textSubtle} />
                  </Pressable>
                </View>
              ))}
          </View>
        ))
      )}

      {/* Weight */}
      <View style={styles.sectionRow}>
        <Text style={styles.section}>{t('progress.weight')}</Text>
        <Pressable onPress={() => setModal('weight')} style={styles.addBtn} accessibilityRole="button">
          <Feather name="plus" size={18} color={colors.textOnPrimary} />
          <Text style={styles.addBtnText}>{t('progress.logWeight')}</Text>
        </Pressable>
      </View>
      <Card>
        {latest ? (
          <>
            <View style={{ flexDirection: 'row', gap: spacing.xxl, marginBottom: spacing.lg }}>
              <Stat label={t('progress.weight')} value={`${latest.weight_kg} ${t('common.kg')}`} />
              {goals?.target_weight_kg ? (
                <Stat label={t('progress.target')} value={`${goals.target_weight_kg} ${t('common.kg')}`} />
              ) : null}
            </View>
            <WeightChart logs={weights} target={goals?.target_weight_kg ?? null} />
          </>
        ) : (
          <Text style={styles.muted}>{t('progress.noWeight')}</Text>
        )}
      </Card>

      <EntryModal
        visible={modal === 'entry'}
        onClose={() => setModal(null)}
        onSaved={() => {
          setModal(null);
          load();
        }}
      />
      <WeightModal
        visible={modal === 'weight'}
        onClose={() => setModal(null)}
        onSaved={() => {
          setModal(null);
          load();
        }}
      />
      <GoalsModal
        visible={modal === 'goals'}
        goals={goals}
        onClose={() => setModal(null)}
        onSaved={() => {
          setModal(null);
          load();
        }}
      />
    </Screen>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <View>
      <Text style={styles.statLabel}>{label}</Text>
      <Text style={styles.statValue}>{value}</Text>
    </View>
  );
}

function MacroBar({ label, value, goal, color }: { label: string; value: number; goal?: number | null; color: string }) {
  const { t } = useI18n();
  const pct = goal ? Math.min(1, value / goal) : 0;
  return (
    <View style={{ gap: 6 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Text style={styles.macroLabel}>{label}</Text>
        <Text style={styles.macroValue}>
          {Math.round(value)}
          {goal ? ` / ${goal}` : ''} {t('common.g')}
        </Text>
      </View>
      <View style={styles.barTrack}>
        <View style={[styles.barFill, { width: `${pct * 100}%`, backgroundColor: color }]} />
      </View>
    </View>
  );
}

function WeightChart({ logs, target }: { logs: WeightLog[]; target: number | null }) {
  const W = 300;
  const H = 110;
  if (logs.length < 2) return null;
  const values = logs.map((l) => Number(l.weight_kg));
  const all = target != null ? [...values, target] : values;
  const min = Math.min(...all) - 1;
  const max = Math.max(...all) + 1;
  const x = (i: number) => (i / (logs.length - 1)) * (W - 12) + 6;
  const y = (v: number) => H - 6 - ((v - min) / (max - min)) * (H - 12);
  const points = values.map((v, i) => `${x(i)},${y(v)}`).join(' ');
  return (
    <View style={{ direction: 'ltr' }}>
      <Svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
        {target != null && (
          <Polyline
            points={`0,${y(target)} ${W},${y(target)}`}
            stroke={colors.proLight}
            strokeWidth={2}
            strokeDasharray="6 6"
          />
        )}
        <Polyline points={points} fill="none" stroke={colors.primary} strokeWidth={3} strokeLinejoin="round" />
        <Circle cx={x(values.length - 1)} cy={y(values[values.length - 1])} r={5} fill={colors.primary} />
      </Svg>
    </View>
  );
}

function Sheet({ visible, onClose, title, children }: { visible: boolean; onClose: () => void; title: string; children: React.ReactNode }) {
  const { isRTL } = useI18n();
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.backdrop}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
        <View style={[styles.sheet, { direction: isRTL ? 'rtl' : 'ltr' }]}>
          <ScrollView contentContainerStyle={{ gap: spacing.lg }} keyboardShouldPersistTaps="handled">
            <Text style={styles.sheetTitle}>{title}</Text>
            {children}
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

function EntryModal({ visible, onClose, onSaved }: { visible: boolean; onClose: () => void; onSaved: () => void }) {
  const { t } = useI18n();
  const { user } = useAuth();
  const [mealType, setMealType] = useState<DiaryMealType>('breakfast');
  const [label, setLabel] = useState('');
  const [cal, setCal] = useState('');
  const [p, setP] = useState('');
  const [c, setC] = useState('');
  const [f, setF] = useState('');
  const [saving, setSaving] = useState(false);

  async function save() {
    const calories = parseNumber(cal);
    if (!label.trim() || calories == null) return Alert.alert(t('progress.invalidNumber'));
    if (!user) return;
    setSaving(true);
    try {
      await addDiaryEntry(user.id, {
        meal_type: mealType,
        manual_label: label.trim().slice(0, 120),
        calories,
        protein_g: parseNumber(p),
        carbs_g: parseNumber(c),
        fat_g: parseNumber(f),
      });
      setLabel('');
      setCal('');
      setP('');
      setC('');
      setF('');
      onSaved();
    } catch (e) {
      captureError(e);
      Alert.alert(t('common.error'));
    } finally {
      setSaving(false);
    }
  }

  return (
    <Sheet visible={visible} onClose={onClose} title={t('progress.addEntry')}>
      <View style={styles.chips}>
        {MEAL_TYPES.map((m) => (
          <Chip key={m} label={t(`meal.${m}` as TKey)} selected={m === mealType} onPress={() => setMealType(m)} />
        ))}
      </View>
      <TextField label={t('progress.entryLabel')} value={label} onChangeText={setLabel} maxLength={120} />
      <TextField label={t('progress.calories')} value={cal} onChangeText={setCal} keyboardType="decimal-pad" />
      <View style={styles.row3}>
        <View style={{ flex: 1 }}>
          <TextField label={t('progress.proteinGoal')} value={p} onChangeText={setP} keyboardType="decimal-pad" />
        </View>
        <View style={{ flex: 1 }}>
          <TextField label={t('progress.carbsGoal')} value={c} onChangeText={setC} keyboardType="decimal-pad" />
        </View>
        <View style={{ flex: 1 }}>
          <TextField label={t('progress.fatGoal')} value={f} onChangeText={setF} keyboardType="decimal-pad" />
        </View>
      </View>
      <Button title={t('common.save')} onPress={save} loading={saving} />
    </Sheet>
  );
}

function WeightModal({ visible, onClose, onSaved }: { visible: boolean; onClose: () => void; onSaved: () => void }) {
  const { t } = useI18n();
  const { user } = useAuth();
  const [w, setW] = useState('');
  const [saving, setSaving] = useState(false);

  async function save() {
    const kg = parseNumber(w);
    if (kg == null || kg < 20 || kg > 400) return Alert.alert(t('progress.invalidNumber'));
    if (!user) return;
    setSaving(true);
    try {
      await logWeight(user.id, kg);
      setW('');
      onSaved();
    } catch (e) {
      captureError(e);
      Alert.alert(t('common.error'));
    } finally {
      setSaving(false);
    }
  }

  return (
    <Sheet visible={visible} onClose={onClose} title={t('progress.logWeight')}>
      <TextField label={t('progress.weightKg')} value={w} onChangeText={setW} keyboardType="decimal-pad" autoFocus />
      <Button title={t('common.save')} onPress={save} loading={saving} />
    </Sheet>
  );
}

function GoalsModal({
  visible,
  goals,
  onClose,
  onSaved,
}: {
  visible: boolean;
  goals: UserGoals | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { t } = useI18n();
  const { user } = useAuth();
  const str = (v: number | null | undefined) => (v == null ? '' : String(v));
  const [cal, setCal] = useState('');
  const [p, setP] = useState('');
  const [c, setC] = useState('');
  const [f, setF] = useState('');
  const [tw, setTw] = useState('');
  const [saving, setSaving] = useState(false);

  // Prefill each time the sheet opens.
  React.useEffect(() => {
    if (!visible) return;
    setCal(str(goals?.daily_calorie_goal));
    setP(str(goals?.protein_goal_g));
    setC(str(goals?.carbs_goal_g));
    setF(str(goals?.fat_goal_g));
    setTw(str(goals?.target_weight_kg));
  }, [visible, goals]);

  async function save() {
    if (!user) return;
    setSaving(true);
    try {
      await saveGoals(user.id, {
        daily_calorie_goal: parseNumber(cal),
        protein_goal_g: parseNumber(p),
        carbs_goal_g: parseNumber(c),
        fat_goal_g: parseNumber(f),
        target_weight_kg: parseNumber(tw),
      });
      onSaved();
    } catch (e) {
      captureError(e);
      Alert.alert(t('common.error'));
    } finally {
      setSaving(false);
    }
  }

  return (
    <Sheet visible={visible} onClose={onClose} title={t('progress.goals')}>
      <TextField label={t('progress.dailyCalories')} value={cal} onChangeText={setCal} keyboardType="decimal-pad" />
      <View style={styles.row3}>
        <View style={{ flex: 1 }}>
          <TextField label={t('progress.proteinGoal')} value={p} onChangeText={setP} keyboardType="decimal-pad" />
        </View>
        <View style={{ flex: 1 }}>
          <TextField label={t('progress.carbsGoal')} value={c} onChangeText={setC} keyboardType="decimal-pad" />
        </View>
        <View style={{ flex: 1 }}>
          <TextField label={t('progress.fatGoal')} value={f} onChangeText={setF} keyboardType="decimal-pad" />
        </View>
      </View>
      <TextField label={t('progress.targetWeight')} value={tw} onChangeText={setTw} keyboardType="decimal-pad" />
      <Button title={t('common.save')} onPress={save} loading={saving} />
    </Sheet>
  );
}

const styles = StyleSheet.create({
  titleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacing.lg,
    marginBottom: spacing.lg,
  },
  title: { fontSize: 28, fontWeight: '800', color: colors.text, marginTop: spacing.lg, letterSpacing: -0.5 },
  subtitle: { fontSize: 13, color: colors.textMuted, marginTop: 2, marginBottom: spacing.lg },
  goalsBtn: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  goalsBtnText: { fontSize: 14, fontWeight: '700', color: colors.primaryText },
  caloriesCard: { flexDirection: 'row', alignItems: 'center', gap: spacing.xxl },
  ringBig: { fontSize: 30, fontWeight: '700', color: colors.text },
  ringSmall: { fontSize: 14, color: colors.textMuted },
  statLabel: { fontSize: 13, color: colors.textMuted },
  statValue: { fontSize: 20, fontWeight: '600', color: colors.text },
  link: { fontSize: 15, fontWeight: '700', color: colors.primaryText },
  macroLabel: { fontSize: 15, fontWeight: '500', color: colors.textBody },
  macroValue: { fontSize: 14, color: colors.textMuted },
  barTrack: { height: 8, borderRadius: 4, backgroundColor: colors.divider, overflow: 'hidden' },
  barFill: { height: 8, borderRadius: 4 },
  sectionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacing.xxxl,
    marginBottom: spacing.md,
  },
  section: { fontSize: 18, fontWeight: '800', color: colors.text },
  addBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: colors.primary,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.md,
    paddingVertical: 8,
  },
  addBtnText: { color: colors.textOnPrimary, fontWeight: '600', fontSize: 14 },
  muted: { fontSize: 15, color: colors.textMuted },
  mealType: { fontSize: 13, fontWeight: '700', color: colors.textMuted, marginBottom: 6, letterSpacing: 0.5 },
  entry: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
    marginBottom: 6,
  },
  entryLabel: { flex: 1, fontSize: 16, color: colors.textBody },
  entryKcal: { fontSize: 15, fontWeight: '600', color: colors.text },
  backdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.35)' },
  sheet: {
    maxHeight: '85%',
    backgroundColor: colors.background,
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    padding: spacing.xxl,
    paddingBottom: spacing.xxxl + spacing.lg,
  },
  sheetTitle: { fontSize: 22, fontWeight: '700', color: colors.text },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  row3: { flexDirection: 'row', gap: spacing.sm },
});
