import React, { useCallback, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Linking, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { CameraView, useCameraPermissions, type BarcodeScanningResult } from 'expo-camera';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { router, useFocusEffect } from 'expo-router';
import { Screen } from '@/src/components/Screen';
import { AppHeader, Button } from '@/src/components/ui';
import { colors, radius, shadow, spacing } from '@/src/constants/theme';
import { useAuth } from '@/src/context/AuthContext';
import { useI18n } from '@/src/context/LanguageContext';
import { findProductIdByBarcode } from '@/src/services/products';
import { recordScan } from '@/src/services/scans';
import { captureError } from '@/src/services/monitoring';

/** Retail product barcode formats. QR codes are deliberately excluded. */
const BARCODE_TYPES = ['ean13', 'ean8', 'upc_a', 'upc_e'] as const;

export default function Scan() {
  const { t } = useI18n();
  const { user } = useAuth();
  const [permission, requestPermission] = useCameraPermissions();
  const [focused, setFocused] = useState(false);
  const [busy, setBusy] = useState(false);
  const [torch, setTorch] = useState(false);
  const [manualCode, setManualCode] = useState('');
  // A ref (not state) so the lock applies synchronously — onBarcodeScanned fires
  // many times per second and state updates would let duplicates through.
  const lock = useRef(false);

  // Only run the camera while this tab is visible (saves battery, frees the camera).
  useFocusEffect(
    useCallback(() => {
      setFocused(true);
      lock.current = false;
      setBusy(false);
      return () => {
        setFocused(false);
        setTorch(false);
      };
    }, []),
  );

  const handleBarcode = useCallback(
    async (code: string) => {
      if (lock.current || !user) return;
      lock.current = true;
      setBusy(true);
      try {
        const productId = await findProductIdByBarcode(code);
        if (productId) {
          recordScan(user.id, productId).catch(captureError);
          router.push(`/product/${productId}`);
        } else {
          // Expected common case early on (small catalog): route to submission, not a dead end.
          router.push({ pathname: '/submit', params: { barcode: code.replace(/\D/g, '') } });
        }
      } catch (e) {
        captureError(e);
        lock.current = false;
        setBusy(false);
        Alert.alert(t('common.error'), t('common.errorBody'));
      }
    },
    [user, t],
  );

  const onScanned = useCallback((result: BarcodeScanningResult) => handleBarcode(result.data), [handleBarcode]);

  function submitManual() {
    const digits = manualCode.replace(/\D/g, '');
    if (digits.length < 8 || digits.length > 14) {
      Alert.alert(t('scan.invalidBarcode'));
      return;
    }
    setManualCode('');
    handleBarcode(digits);
  }

  const granted = permission?.granted;

  return (
    <Screen>
      <AppHeader />
      <Text style={styles.title}>{t('scan.title')}</Text>
      <Text style={styles.subtitle}>{t('scan.subtitle')}</Text>

      {/* Camera card */}
      <View style={styles.camera}>
        {granted && focused && (
          <CameraView
            style={StyleSheet.absoluteFill}
            facing="back"
            enableTorch={torch}
            barcodeScannerSettings={{ barcodeTypes: [...BARCODE_TYPES] }}
            onBarcodeScanned={busy ? undefined : onScanned}
          />
        )}

        {!granted && permission && (
          <View style={styles.permission}>
            <Feather name="camera" size={34} color="rgba(255,255,255,0.55)" />
            <Text style={styles.permissionTitle}>{t('scan.permissionTitle')}</Text>
            <Text style={styles.permissionBody}>{t('scan.permissionBody')}</Text>
            <Button
              compact
              title={permission.canAskAgain ? t('scan.grantPermission') : t('scan.openSettings')}
              onPress={() => (permission.canAskAgain ? requestPermission() : Linking.openSettings())}
            />
          </View>
        )}

        <View pointerEvents="none" style={StyleSheet.absoluteFill}>
          <View style={[styles.corner, styles.tl]} />
          <View style={[styles.corner, styles.tr]} />
          <View style={[styles.corner, styles.bl]} />
          <View style={[styles.corner, styles.br]} />
        </View>

        {granted && (
          <>
            <Pressable
              onPress={() => setTorch((v) => !v)}
              accessibilityRole="button"
              accessibilityLabel={t('scan.torch')}
              style={styles.torch}
            >
              <Feather name={torch ? 'zap' : 'zap-off'} size={18} color="#fff" />
            </Pressable>
            <View style={styles.status} pointerEvents="none">
              {busy && <ActivityIndicator color="#fff" size="small" />}
              <Text style={styles.statusText}>{busy ? t('scan.lookingUp') : t('scan.hint')}</Text>
            </View>
          </>
        )}
      </View>

      {/* Manual entry */}
      <View style={styles.manual}>
        <View style={styles.manualHead}>
          <MaterialCommunityIcons name="keyboard-outline" size={18} color={colors.textBody} />
          <Text style={styles.manualTitle}>{t('scan.manualTitle')}</Text>
        </View>
        <View style={styles.manualRow}>
          <View style={styles.inputWrap}>
            <Feather name="search" size={15} color={colors.textSubtle} />
            <TextInput
              value={manualCode}
              onChangeText={setManualCode}
              placeholder="e.g. 6221035000017"
              placeholderTextColor={colors.textSubtle}
              keyboardType="number-pad"
              maxLength={14}
              onSubmitEditing={submitManual}
              style={styles.input}
            />
          </View>
          <Button title={t('scan.lookup')} variant="dark" compact onPress={submitManual} style={styles.lookup} />
        </View>
        <Text style={styles.tip}>{t('scan.tip')}</Text>
      </View>
    </Screen>
  );
}

const CORNER = 30;
const INSET = 18;
const styles = StyleSheet.create({
  title: { fontSize: 26, fontWeight: '800', color: colors.text, textAlign: 'center', marginTop: spacing.lg },
  subtitle: { fontSize: 13, color: colors.textMuted, textAlign: 'center', marginTop: 4, marginBottom: spacing.lg },
  camera: {
    height: 380,
    borderRadius: radius.xl,
    backgroundColor: colors.cameraBg,
    overflow: 'hidden',
    justifyContent: 'center',
  },
  corner: { position: 'absolute', width: CORNER, height: CORNER, borderColor: colors.accentMint },
  tl: { top: INSET, left: INSET, borderTopWidth: 3, borderLeftWidth: 3, borderTopLeftRadius: 6 },
  tr: { top: INSET, right: INSET, borderTopWidth: 3, borderRightWidth: 3, borderTopRightRadius: 6 },
  bl: { bottom: INSET, left: INSET, borderBottomWidth: 3, borderLeftWidth: 3, borderBottomLeftRadius: 6 },
  br: { bottom: INSET, right: INSET, borderBottomWidth: 3, borderRightWidth: 3, borderBottomRightRadius: 6 },
  permission: { alignItems: 'center', gap: spacing.sm, paddingHorizontal: spacing.xxxl },
  permissionTitle: { color: '#fff', fontSize: 16, fontWeight: '700', marginTop: spacing.sm },
  permissionBody: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 13,
    textAlign: 'center',
    lineHeight: 18,
    marginBottom: spacing.sm,
  },
  torch: {
    position: 'absolute',
    top: INSET + 8,
    alignSelf: 'center',
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: 'rgba(0,0,0,0.4)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  status: {
    position: 'absolute',
    bottom: INSET + 10,
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: 'rgba(0,0,0,0.45)',
    borderRadius: radius.pill,
    paddingHorizontal: 14,
    paddingVertical: 7,
  },
  statusText: { color: '#fff', fontSize: 13, fontWeight: '600' },
  manual: {
    marginTop: spacing.lg,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
    gap: spacing.md,
    ...shadow.card,
  },
  manualHead: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  manualTitle: { fontSize: 14, fontWeight: '700', color: colors.text },
  manualRow: { flexDirection: 'row', gap: spacing.sm, alignItems: 'center' },
  inputWrap: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    height: 44,
    borderRadius: radius.sm,
    backgroundColor: colors.surfaceMuted,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
  },
  input: { flex: 1, fontSize: 14, color: colors.textBody, paddingVertical: 0 },
  lookup: { borderRadius: radius.sm, height: 44 },
  tip: { fontSize: 12, color: colors.textMuted },
});
