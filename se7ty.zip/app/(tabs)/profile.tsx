import React, { useEffect, useState } from 'react';
import { Alert, Linking, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import Constants from 'expo-constants';
import { router } from 'expo-router';
import { Screen } from '@/src/components/Screen';
import { AppHeader, Button, ForwardArrow } from '@/src/components/ui';
import { colors, radius, shadow, spacing } from '@/src/constants/theme';
import { useAuth } from '@/src/context/AuthContext';
import { useI18n } from '@/src/context/LanguageContext';
import type { TKey } from '@/src/i18n/strings';
import { PACKAGE_TYPE } from 'react-native-purchases';
import { getPackages, isPurchasesConfigured } from '@/src/services/subscriptions';
import { captureError } from '@/src/services/monitoring';
import type { Language } from '@/src/types/database';

const PRO_FEATURES: TKey[] = ['paywall.f1', 'paywall.f2', 'paywall.f3', 'paywall.f4'];

export default function Profile() {
  const { t, language, setLanguage } = useI18n();
  const { user, profile, isPro, signOut, updateProfile } = useAuth();
  const [price, setPrice] = useState<string | null>(null);

  // Show the real store price (localized, e.g. "EGP 49.00") instead of hardcoding it.
  useEffect(() => {
    if (isPro || !isPurchasesConfigured()) return;
    getPackages()
      .then((pkgs) => {
        const monthly = pkgs.find((p) => p.packageType === PACKAGE_TYPE.MONTHLY) ?? pkgs[0];
        if (monthly) setPrice(monthly.product.priceString);
      })
      .catch(() => {});
  }, [isPro]);

  const name = profile?.display_name || t('profile.member');
  const initial = name.trim().charAt(0).toUpperCase() || 'S';

  async function changeLanguage(lang: Language) {
    if (lang === language) return;
    try {
      const needsRestart = await setLanguage(lang);
      await updateProfile({ preferred_language: lang });
      if (needsRestart) Alert.alert(t('profile.restartTitle'), t('profile.restartBody'));
    } catch (e) {
      captureError(e);
    }
  }

  function pickLanguage() {
    Alert.alert(t('profile.language'), undefined, [
      { text: 'العربية', onPress: () => changeLanguage('ar') },
      { text: 'English', onPress: () => changeLanguage('en') },
      { text: t('common.cancel'), style: 'cancel' },
    ]);
  }

  function manageSubscription() {
    const url =
      Platform.OS === 'ios'
        ? 'https://apps.apple.com/account/subscriptions'
        : 'https://play.google.com/store/account/subscriptions';
    Linking.openURL(url).catch(() => {});
  }

  return (
    <Screen>
      <AppHeader />

      {/* Member card */}
      <View style={[styles.card, styles.member]}>
        <LinearGradient colors={[colors.primary, colors.primaryGradientEnd]} style={styles.avatar}>
          <Text style={styles.avatarText}>{initial}</Text>
        </LinearGradient>
        <View style={{ flex: 1 }}>
          <Text style={styles.memberName} numberOfLines={1}>
            {name}
          </Text>
          <Text style={styles.memberEmail} numberOfLines={1}>
            {user?.email}
          </Text>
        </View>
      </View>

      {/* Plan */}
      {isPro ? (
        <View style={[styles.card, { gap: spacing.md }]}>
          <View style={styles.planHead}>
            <View style={styles.crown}>
              <MaterialCommunityIcons name="crown-outline" size={20} color={colors.pro} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.small}>{t('profile.currentPlan')}</Text>
              <Text style={styles.planTitle}>{t('profile.pro')}</Text>
              {profile?.subscription_expires_at && (
                <Text style={styles.small}>
                  {t('profile.proUntil', {
                    date: new Date(profile.subscription_expires_at).toLocaleDateString(
                      language === 'ar' ? 'ar-EG' : 'en-GB',
                    ),
                  })}
                </Text>
              )}
            </View>
          </View>
          <Button title={t('profile.manage')} variant="secondary" compact onPress={manageSubscription} />
        </View>
      ) : (
        <View style={[styles.card, { gap: spacing.md }]}>
          <View style={styles.planHead}>
            <View style={styles.crown}>
              <MaterialCommunityIcons name="crown-outline" size={20} color={colors.pro} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.planTitle}>{t('profile.upgradeTitle')}</Text>
              <Text style={styles.small}>{t('profile.upgradeSub')}</Text>
            </View>
          </View>
          {price && (
            <View style={styles.priceBox}>
              <Text style={styles.price}>{price}</Text>
              <Text style={styles.small}> {t('profile.perMonth')}</Text>
            </View>
          )}
          <View style={{ gap: 8 }}>
            {PRO_FEATURES.map((k) => (
              <View key={k} style={styles.feature}>
                <View style={styles.check}>
                  <Feather name="check" size={11} color={colors.primaryText} />
                </View>
                <Text style={styles.featureText}>{t(k)}</Text>
              </View>
            ))}
          </View>
          <Button
            title={t('profile.startPro')}
            variant="pro"
            onPress={() => router.push('/paywall')}
            icon={<MaterialCommunityIcons name="crown-outline" size={18} color="#fff" />}
          />
        </View>
      )}

      {/* Settings */}
      <View style={[styles.card, { paddingVertical: 0 }]}>
        <Row icon="bell" label={t('profile.notifications')} onPress={() => Alert.alert(t('common.comingSoon'))} />
        <Row
          icon="globe"
          label={t('profile.language')}
          value={language === 'ar' ? 'العربية' : 'English'}
          onPress={pickLanguage}
        />
        <Row icon="maximize" label={t('profile.myScans')} onPress={() => router.push('/history')} />
        <Row icon="info" label={t('product.scoringMethod')} onPress={() => router.push('/scoring-method')} />
        <Row icon="heart" label={t('profile.about')} onPress={() => Alert.alert('Se7ty', t('profile.disclaimer'))} />
        <Row icon="help-circle" label={t('profile.help')} onPress={() => Alert.alert(t('common.comingSoon'))} />
        <Row icon="log-out" label={t('profile.signOut')} onPress={signOut} danger last />
      </View>

      <Text style={styles.footer}>Se7ty · {t('brand.tagline')}</Text>
      <Text style={styles.footerSmall}>
        {t('profile.version', { version: Constants.expoConfig?.version ?? '0.0.0' })}
      </Text>
    </Screen>
  );
}

function Row({
  icon,
  label,
  value,
  onPress,
  danger,
  last,
}: {
  icon: React.ComponentProps<typeof Feather>['name'];
  label: string;
  value?: string;
  onPress: () => void;
  danger?: boolean;
  last?: boolean;
}) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      style={({ pressed }) => [styles.row, !last && styles.rowDivider, pressed && { opacity: 0.6 }]}
    >
      <View style={styles.rowIcon}>
        <Feather name={icon} size={16} color={danger ? colors.danger : colors.textMuted} />
      </View>
      <Text style={[styles.rowLabel, danger && { color: colors.danger }]}>{label}</Text>
      {value ? <Text style={styles.rowValue}>{value}</Text> : null}
      {!danger && <ForwardArrow size={18} />}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    marginTop: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
    ...shadow.card,
  },
  member: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginTop: spacing.sm },
  avatar: { width: 52, height: 52, borderRadius: 26, alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: '#fff', fontSize: 20, fontWeight: '800' },
  memberName: { fontSize: 18, fontWeight: '800', color: colors.text },
  memberEmail: { fontSize: 13, color: colors.textMuted },
  planHead: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  crown: {
    width: 38,
    height: 38,
    borderRadius: 10,
    backgroundColor: colors.proSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  planTitle: { fontSize: 16, fontWeight: '800', color: colors.text },
  small: { fontSize: 12, color: colors.textMuted },
  priceBox: {
    flexDirection: 'row',
    alignItems: 'baseline',
    backgroundColor: colors.surfaceMuted,
    borderRadius: radius.md,
    padding: spacing.lg,
  },
  price: { fontSize: 24, fontWeight: '800', color: colors.text },
  feature: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  check: {
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  featureText: { flex: 1, fontSize: 13, color: colors.textBody },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, paddingVertical: 14 },
  rowDivider: { borderBottomWidth: 1, borderBottomColor: colors.divider },
  rowIcon: {
    width: 30,
    height: 30,
    borderRadius: 8,
    backgroundColor: colors.surfaceMuted,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rowLabel: { flex: 1, fontSize: 14, color: colors.textBody },
  rowValue: { fontSize: 13, color: colors.textMuted },
  footer: { textAlign: 'center', fontSize: 12, color: colors.textMuted, marginTop: spacing.xl },
  footerSmall: { textAlign: 'center', fontSize: 11, color: colors.textSubtle, marginTop: 4 },
});
