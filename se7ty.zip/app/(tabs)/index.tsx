import React, { useCallback, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useFocusEffect } from 'expo-router';
import { Screen } from '@/src/components/Screen';
import { ProductRow } from '@/src/components/ProductRow';
import { Ring } from '@/src/components/Score';
import { AppHeader, ForwardArrow, ProBadge, SectionLabel } from '@/src/components/ui';
import { ProGate } from '@/src/components/ProGate';
import { colors, radius, shadow, spacing } from '@/src/constants/theme';
import { useAuth } from '@/src/context/AuthContext';
import { useI18n } from '@/src/context/LanguageContext';
import type { TKey } from '@/src/i18n/strings';
import { getRecentScans } from '@/src/services/scans';
import { getDiaryForDate, getGoals, getWeightLogs, sumDiary } from '@/src/services/progress';
import { captureError } from '@/src/services/monitoring';
import type { ScanWithProduct } from '@/src/types/database';

interface TodaySummary {
  calories: number;
  calorieGoal: number | null;
  protein: number;
  proteinGoal: number | null;
  weight: number | null;
  targetWeight: number | null;
}

export default function Home() {
  const { t } = useI18n();
  const { user, isPro } = useAuth();
  const [recent, setRecent] = useState<ScanWithProduct[]>([]);
  const [today, setToday] = useState<TodaySummary | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    if (!user) return;
    try {
      setRecent(await getRecentScans(6));
      if (isPro) {
        const [diary, goals, weights] = await Promise.all([
          getDiaryForDate(user.id),
          getGoals(user.id),
          getWeightLogs(user.id, 1),
        ]);
        const sum = sumDiary(diary);
        setToday({
          calories: Math.round(sum.calories),
          calorieGoal: goals?.daily_calorie_goal ?? null,
          protein: Math.round(sum.protein),
          proteinGoal: goals?.protein_goal_g ?? null,
          weight: weights[0]?.weight_kg ?? null,
          targetWeight: goals?.target_weight_kg ?? null,
        });
      }
    } catch (e) {
      captureError(e);
    }
  }, [user, isPro]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load]),
  );

  async function onRefresh() {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  }

  return (
    <Screen refreshing={refreshing} onRefresh={onRefresh}>
      <AppHeader />

      {/* Search */}
      <View style={styles.search}>
        <Pressable onPress={() => router.push('/search')} accessibilityRole="search" style={styles.searchPress}>
          <Feather name="search" size={18} color={colors.textMuted} />
          <Text style={styles.searchText} numberOfLines={1}>
            {t('home.searchPlaceholder')}
          </Text>
        </Pressable>
        <Pressable onPress={() => router.navigate('/scan')} style={styles.searchScan} accessibilityRole="button">
          <MaterialCommunityIcons name="line-scan" size={15} color={colors.primaryText} />
          <Text style={styles.searchScanText}>{t('tabs.scan')}</Text>
        </Pressable>
      </View>

      {/* Scan hero */}
      <LinearGradient
        colors={[colors.primary, colors.primaryGradientEnd]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.hero}
      >
        <View style={styles.liveChip}>
          <Feather name="camera" size={11} color="#fff" />
          <Text style={styles.liveChipText}>{t('home.liveCamera')}</Text>
        </View>
        <View style={styles.heroRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.heroTitle}>{t('home.scanTitle')}</Text>
            <Text style={styles.heroBody}>{t('home.scanSubtitle')}</Text>
          </View>
          <View style={styles.heroPreview}>
            <View style={styles.heroPreviewInner}>
              <View style={styles.heroLine} />
              <MaterialCommunityIcons name="scan-helper" size={26} color="rgba(255,255,255,0.8)" />
            </View>
          </View>
        </View>
        <Pressable
          onPress={() => router.navigate('/scan')}
          accessibilityRole="button"
          style={({ pressed }) => [styles.heroButton, pressed && { opacity: 0.9 }]}
        >
          <Text style={styles.heroButtonText}>{t('home.startScanning')}</Text>
          <MaterialCommunityIcons name="line-scan" size={16} color={colors.primaryText} />
        </Pressable>
      </LinearGradient>

      {/* My Progress — live for Pro, locked teaser for Free */}
      <View style={styles.progressCard}>
        <View style={styles.progressHead}>
          <Text style={styles.progressTitle}>{t('home.myProgress')}</Text>
          <Pressable onPress={() => router.navigate('/progress')} style={styles.openLink} hitSlop={8}>
            <Text style={styles.openText}>{t('common.open')}</Text>
            <ForwardArrow size={14} color={colors.primaryText} />
          </Pressable>
        </View>
        {isPro ? (
          <View style={styles.rings}>
            <MiniRing
              label={t('home.ringCalories')}
              value={today ? `${today.calories}` : '—'}
              sub={today?.calorieGoal ? `/ ${today.calorieGoal}` : t('common.kcal')}
              percent={today?.calorieGoal ? (today.calories / today.calorieGoal) * 100 : 0}
              color={colors.judgment.good}
            />
            <MiniRing
              label={t('home.ringProtein')}
              value={today ? `${today.protein}${t('common.g')}` : '—'}
              sub={today?.proteinGoal ? `/ ${today.proteinGoal}${t('common.g')}` : ''}
              percent={today?.proteinGoal ? (today.protein / today.proteinGoal) * 100 : 0}
              color={colors.primary}
            />
            <MiniRing
              label={t('home.ringWeight')}
              value={today?.weight != null ? `${today.weight}` : '—'}
              sub={t('common.kg')}
              percent={today?.weight && today.targetWeight ? Math.min(today.weight, today.targetWeight) / Math.max(today.weight, today.targetWeight) * 100 : 0}
              color={colors.proLight}
            />
          </View>
        ) : (
          <ProGate body={t('home.unlockTracking')} title="" bare />
        )}
      </View>

      {/* Categories */}
      <SectionLabel title={t('home.categories')} />
      <View style={styles.tiles}>
        <Tile
          icon="food-apple"
          iconColor="#E0483E"
          title="home.catFood"
          sub="home.catFoodSub"
          onPress={() => router.push({ pathname: '/search', params: { category: 'food' } })}
        />
        <Tile
          icon="lotion-outline"
          iconColor="#E27AA0"
          title="home.catCosmetics"
          sub="home.catCosmeticsSub"
          onPress={() => router.push({ pathname: '/search', params: { category: 'cosmetics' } })}
        />
      </View>
      <View style={[styles.tiles, { marginTop: spacing.sm }]}>
        <Tile
          icon="pill"
          iconColor="#E0703E"
          title="home.catSupplements"
          sub="home.catSupplementsSub"
          onPress={() => router.push({ pathname: '/search', params: { category: 'supplements' } })}
        />
        <Tile
          icon="silverware-fork-knife"
          iconColor="#7C6FD6"
          title="home.catMeal"
          sub="home.catMealSub"
          pro
          onPress={() => router.push('/meal-scanner')}
        />
      </View>

      {/* Recent scans */}
      <SectionLabel
        title={t('home.recentScansLabel')}
        right={
          recent.length > 0 ? (
            <Pressable onPress={() => router.push('/history')} hitSlop={8}>
              <Text style={styles.viewAll}>{t('common.viewAll')}</Text>
            </Pressable>
          ) : undefined
        }
      />
      {recent.length === 0 ? (
        <View style={styles.empty}>
          <MaterialCommunityIcons name="barcode-scan" size={28} color={colors.textSubtle} />
          <Text style={styles.emptyText}>{t('home.noScans')}</Text>
        </View>
      ) : (
        recent.map((s) => <ProductRow key={s.id} product={s.product} />)
      )}
    </Screen>
  );
}

function MiniRing({
  label,
  value,
  sub,
  percent,
  color,
}: {
  label: string;
  value: string;
  sub: string;
  percent: number;
  color: string;
}) {
  return (
    <View style={{ alignItems: 'center', gap: 6, flex: 1 }}>
      <Ring percent={percent} size={74} stroke={6} color={color}>
        <Text style={styles.miniValue}>{value}</Text>
      </Ring>
      <Text style={styles.miniLabel}>{label}</Text>
      {sub ? <Text style={styles.miniSub}>{sub}</Text> : null}
    </View>
  );
}

function Tile({
  icon,
  iconColor,
  title,
  sub,
  pro,
  onPress,
}: {
  icon: React.ComponentProps<typeof MaterialCommunityIcons>['name'];
  iconColor: string;
  title: TKey;
  sub: TKey;
  pro?: boolean;
  onPress: () => void;
}) {
  const { t } = useI18n();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      style={({ pressed }) => [styles.tile, pressed && { opacity: 0.85 }]}
    >
      <View style={styles.tileTop}>
        <MaterialCommunityIcons name={icon} size={28} color={iconColor} />
        {pro && <ProBadge />}
      </View>
      <Text style={styles.tileTitle}>{t(title)}</Text>
      <Text style={styles.tileSub}>{t(sub)}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  search: {
    marginTop: spacing.sm,
    height: 52,
    borderRadius: radius.md,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    flexDirection: 'row',
    alignItems: 'center',
    paddingStart: spacing.lg,
    paddingEnd: 6,
    ...shadow.card,
  },
  searchPress: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: spacing.sm, height: '100%' },
  searchText: { flex: 1, fontSize: 14, color: colors.textMuted },
  searchScan: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: colors.primarySoft,
    borderRadius: radius.sm,
    paddingHorizontal: 10,
    paddingVertical: 8,
  },
  searchScanText: { fontSize: 13, fontWeight: '700', color: colors.primaryText },
  hero: {
    marginTop: spacing.lg,
    borderRadius: radius.xl,
    padding: spacing.xl,
    gap: spacing.md,
  },
  liveChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(255,255,255,0.16)',
    borderRadius: radius.pill,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  liveChipText: { color: '#fff', fontSize: 11, fontWeight: '700' },
  heroRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  heroTitle: { fontSize: 30, fontWeight: '800', color: '#fff', letterSpacing: -0.8 },
  heroBody: { marginTop: 6, fontSize: 14, lineHeight: 20, color: colors.textOnPrimaryMuted },
  heroPreview: {
    width: 104,
    height: 88,
    borderRadius: radius.md,
    backgroundColor: 'rgba(0,0,0,0.14)',
    padding: 7,
  },
  heroPreviewInner: {
    flex: 1,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.35)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroLine: { position: 'absolute', left: 0, right: 0, height: 1, backgroundColor: 'rgba(255,255,255,0.4)' },
  heroButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    alignSelf: 'flex-start',
    backgroundColor: '#fff',
    borderRadius: radius.pill,
    paddingHorizontal: spacing.lg,
    paddingVertical: 11,
    marginTop: spacing.xs,
  },
  heroButtonText: { fontSize: 14, fontWeight: '700', color: colors.primaryText },
  progressCard: {
    marginTop: spacing.lg,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
    gap: spacing.md,
    ...shadow.card,
  },
  progressHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  progressTitle: { fontSize: 16, fontWeight: '800', color: colors.text },
  openLink: { flexDirection: 'row', alignItems: 'center', gap: 2 },
  openText: { fontSize: 13, fontWeight: '700', color: colors.primaryText },
  rings: { flexDirection: 'row', justifyContent: 'space-between' },
  miniValue: { fontSize: 13, fontWeight: '800', color: colors.text },
  miniLabel: { fontSize: 12, fontWeight: '600', color: colors.textBody },
  miniSub: { fontSize: 11, color: colors.textSubtle, marginTop: -4 },
  tiles: { flexDirection: 'row', gap: spacing.sm },
  tile: {
    flex: 1,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    minHeight: 104,
    ...shadow.card,
  },
  tileTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: spacing.md },
  tileTitle: { fontSize: 14, fontWeight: '700', color: colors.text },
  tileSub: { fontSize: 12, color: colors.textMuted, marginTop: 2 },
  viewAll: { fontSize: 13, fontWeight: '700', color: colors.primaryText },
  empty: {
    alignItems: 'center',
    gap: spacing.sm,
    padding: spacing.xxl,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    borderStyle: 'dashed',
  },
  emptyText: { fontSize: 14, color: colors.textMuted, textAlign: 'center' },
});
