import React, { useEffect } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import { AuthProvider, useAuth } from '@/src/context/AuthContext';
import { LanguageProvider } from '@/src/context/LanguageContext';
import { initMonitoring, Sentry } from '@/src/services/monitoring';
import { colors } from '@/src/constants/theme';

initMonitoring();
SplashScreen.preventAutoHideAsync().catch(() => {});

/**
 * Auth gating uses Expo Router's `Stack.Protected` (the documented approach since
 * SDK 53, verified against current docs). A guarded screen is unreachable —
 * including via deep link — while its guard is false; the router redirects to
 * the first available screen instead.
 *
 * Note: this only gates *navigation*. Data access is enforced by Supabase RLS,
 * and Pro-only screens re-check `isPro` themselves (brief §4.3).
 */
function RootNavigator() {
  const { session, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading) SplashScreen.hideAsync().catch(() => {});
  }, [isLoading]);

  if (isLoading) return null;

  return (
    <Stack
      screenOptions={{
        headerShown: false,
        contentStyle: { backgroundColor: colors.background },
      }}
    >
      <Stack.Protected guard={!!session}>
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="product/[id]" />
        <Stack.Screen name="submit" />
        <Stack.Screen name="search" />
        <Stack.Screen name="history" />
        <Stack.Screen name="meal-scanner" />
        <Stack.Screen name="paywall" options={{ presentation: 'modal' }} />
        <Stack.Screen name="scoring-method" options={{ presentation: 'modal' }} />
      </Stack.Protected>
      <Stack.Protected guard={!session}>
        <Stack.Screen name="(auth)" />
      </Stack.Protected>
    </Stack>
  );
}

function RootLayout() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <StatusBar style="dark" />
        <RootNavigator />
      </AuthProvider>
    </LanguageProvider>
  );
}

export default Sentry.wrap(RootLayout);
