import React, { useCallback, useState } from 'react';
import { StyleSheet, Text } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { Screen } from '@/src/components/Screen';
import { StackHeader } from '@/src/components/StackHeader';
import { ProductRow } from '@/src/components/ProductRow';
import { Loading } from '@/src/components/ui';
import { colors, spacing } from '@/src/constants/theme';
import { useI18n } from '@/src/context/LanguageContext';
import { getRecentScans } from '@/src/services/scans';
import { captureError } from '@/src/services/monitoring';
import type { ScanWithProduct } from '@/src/types/database';

export default function History() {
  const { t } = useI18n();
  const [scans, setScans] = useState<ScanWithProduct[] | null>(null);

  useFocusEffect(
    useCallback(() => {
      getRecentScans(100)
        .then(setScans)
        .catch((e) => {
          captureError(e);
          setScans([]);
        });
    }, []),
  );

  return (
    <Screen>
      <StackHeader title={t('history.title')} />
      {scans == null ? (
        <Loading />
      ) : scans.length === 0 ? (
        <Text style={styles.empty}>{t('history.empty')}</Text>
      ) : (
        scans.map((s) => <ProductRow key={s.id} product={s.product} />)
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  empty: { fontSize: 14, color: colors.textMuted, textAlign: 'center', marginTop: spacing.xxl },
});
