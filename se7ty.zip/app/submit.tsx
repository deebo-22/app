import React, { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, StyleSheet, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { Screen } from '@/src/components/Screen';
import { StackHeader } from '@/src/components/StackHeader';
import { Button, Card, Chip, TextField } from '@/src/components/ui';
import { colors, radius, spacing } from '@/src/constants/theme';
import { useAuth } from '@/src/context/AuthContext';
import { useI18n } from '@/src/context/LanguageContext';
import type { TKey } from '@/src/i18n/strings';
import { submitProduct } from '@/src/services/catalog';
import { captureError } from '@/src/services/monitoring';
import type { ProductCategory } from '@/src/types/database';
import { parseNumber } from '@/src/utils/date';

const NUTRITION_FIELDS = [
  ['energy_kcal', 'submit.energy'],
  ['sugar_g', 'submit.sugar'],
  ['saturates_g', 'submit.saturates'],
  ['salt_g', 'submit.salt'],
  ['protein_g', 'submit.protein'],
  ['carbs_g', 'submit.carbs'],
  ['fiber_g', 'submit.fiber'],
] as const satisfies readonly (readonly [string, TKey])[];

type NutritionKey = (typeof NUTRITION_FIELDS)[number][0];

/**
 * "Product not found" flow. Writes to the product_submissions moderation queue —
 * nothing here reaches the public catalog until an admin approves it.
 */
export default function Submit() {
  const { t } = useI18n();
  const { user } = useAuth();
  const { barcode = '' } = useLocalSearchParams<{ barcode: string }>();
  const cleanBarcode = String(barcode).replace(/\D/g, '').slice(0, 14);

  const [name, setName] = useState('');
  const [brand, setBrand] = useState('');
  const [category, setCategory] = useState<ProductCategory>('food');
  const [unit, setUnit] = useState<'100g' | '100ml'>('100g');
  const [nutrition, setNutrition] = useState<Record<NutritionKey, string>>({
    energy_kcal: '',
    sugar_g: '',
    saturates_g: '',
    salt_g: '',
    protein_g: '',
    carbs_g: '',
    fiber_g: '',
  });
  const [ingredients, setIngredients] = useState('');
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState(false);

  async function send() {
    if (!name.trim()) return Alert.alert(t('submit.nameRequired'));
    if (!user || !cleanBarcode) return;
    setSending(true);
    try {
      const parsed = Object.fromEntries(
        NUTRITION_FIELDS.map(([k]) => [k, parseNumber(nutrition[k])]),
      ) as Record<NutritionKey, number | null>;
      await submitProduct(user.id, cleanBarcode, {
        name: name.trim().slice(0, 200),
        brand: brand.trim().slice(0, 120) || undefined,
        category,
        serving_unit: unit,
        nutrition: category === 'food' ? parsed : undefined,
        ingredients_text: ingredients.trim().slice(0, 4000) || undefined,
      });
      setDone(true);
    } catch (e) {
      captureError(e);
      Alert.alert(t('common.error'), t('common.errorBody'));
    } finally {
      setSending(false);
    }
  }

  if (done) {
    return (
      <Screen contentStyle={styles.doneWrap}>
        <View style={styles.doneIcon}>
          <Feather name="check" size={36} color={colors.primary} />
        </View>
        <Text style={styles.doneTitle}>{t('submit.thanksTitle')}</Text>
        <Text style={styles.doneBody}>{t('submit.thanksBody')}</Text>
        <Button title={t('submit.scanAnother')} onPress={() => router.replace('/scan')} style={{ alignSelf: 'stretch' }} />
        <Button title={t('submit.backHome')} variant="ghost" onPress={() => router.replace('/')} />
      </Screen>
    );
  }

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Screen>
        <StackHeader />
        <View style={styles.hero}>
          <Feather name="package" size={26} color={colors.primary} />
          <Text style={styles.title}>{t('submit.title')}</Text>
          <Text style={styles.subtitle}>{t('submit.subtitle', { barcode: cleanBarcode })}</Text>
        </View>

        <Card style={{ gap: spacing.md }}>
          <TextField label={t('submit.name')} value={name} onChangeText={setName} maxLength={200} />
          <TextField label={t('submit.brand')} value={brand} onChangeText={setBrand} maxLength={120} />
          <Text style={styles.label}>{t('submit.category')}</Text>
          <View style={styles.chips}>
            {(['food', 'cosmetics', 'supplements'] as ProductCategory[]).map((c) => (
              <Chip key={c} label={t(`category.${c}`)} selected={c === category} onPress={() => setCategory(c)} />
            ))}
          </View>
        </Card>

        {category === 'food' && (
          <Card style={{ gap: spacing.md, marginTop: spacing.md }}>
            <Text style={styles.cardTitle}>{t('submit.nutrition')}</Text>
            <Text style={styles.label}>{t('submit.unit')}</Text>
            <View style={styles.chips}>
              <Chip label="100 g" selected={unit === '100g'} onPress={() => setUnit('100g')} />
              <Chip label="100 mL" selected={unit === '100ml'} onPress={() => setUnit('100ml')} />
            </View>
            <View style={styles.grid}>
              {NUTRITION_FIELDS.map(([key, label]) => (
                <View key={key} style={styles.gridItem}>
                  <TextField
                    label={t(label)}
                    value={nutrition[key]}
                    onChangeText={(v) => setNutrition((n) => ({ ...n, [key]: v }))}
                    keyboardType="decimal-pad"
                    maxLength={8}
                  />
                </View>
              ))}
            </View>
          </Card>
        )}

        <Card style={{ gap: spacing.md, marginTop: spacing.md }}>
          <TextField
            label={t('submit.ingredients')}
            placeholder={t('submit.ingredientsHint')}
            value={ingredients}
            onChangeText={setIngredients}
            multiline
            maxLength={4000}
            style={{ minHeight: 110, textAlignVertical: 'top' }}
          />
        </Card>

        <Button title={t('submit.send')} onPress={send} loading={sending} style={{ marginTop: spacing.xl }} />
      </Screen>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  hero: { alignItems: 'center', gap: 6, marginBottom: spacing.lg },
  title: { fontSize: 22, fontWeight: '800', color: colors.text, textAlign: 'center' },
  subtitle: { fontSize: 13, color: colors.textMuted, textAlign: 'center', lineHeight: 19 },
  cardTitle: { fontSize: 15, fontWeight: '800', color: colors.text },
  label: { fontSize: 13, fontWeight: '600', color: colors.textBody },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  grid: { flexDirection: 'row', flexWrap: 'wrap', marginHorizontal: -4 },
  gridItem: { width: '50%', paddingHorizontal: 4, marginBottom: spacing.sm },
  doneWrap: { flexGrow: 1, alignItems: 'center', justifyContent: 'center', gap: spacing.md },
  doneIcon: {
    width: 76,
    height: 76,
    borderRadius: 38,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  doneTitle: { fontSize: 24, fontWeight: '800', color: colors.text },
  doneBody: { fontSize: 14, color: colors.textMuted, textAlign: 'center', marginBottom: spacing.lg, borderRadius: radius.sm },
});
