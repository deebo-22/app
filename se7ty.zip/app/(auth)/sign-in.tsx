import React, { useState } from 'react';
import { Alert } from 'react-native';
import { router } from 'expo-router';
import { AuthShell } from '@/src/components/AuthShell';
import { Button, TextField } from '@/src/components/ui';
import { useAuth } from '@/src/context/AuthContext';
import { useI18n } from '@/src/context/LanguageContext';

export default function SignIn() {
  const { t } = useI18n();
  const { signIn } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  async function onSubmit() {
    if (!email.trim() || !password) return Alert.alert(t('auth.fillAll'));
    setLoading(true);
    try {
      await signIn(email, password);
      // On success the auth listener updates the session and Stack.Protected
      // swaps to the tabs automatically — no manual navigation needed.
    } catch {
      // Deliberately generic: don't reveal whether the email exists.
      Alert.alert(t('auth.signInFailed'));
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthShell title={t('auth.signInTitle')} subtitle={t('auth.signInSubtitle')}>
      <TextField
        label={t('auth.email')}
        value={email}
        onChangeText={setEmail}
        autoCapitalize="none"
        autoComplete="email"
        keyboardType="email-address"
        textContentType="emailAddress"
      />
      <TextField
        label={t('auth.password')}
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        autoComplete="current-password"
        textContentType="password"
        onSubmitEditing={onSubmit}
      />
      <Button title={t('auth.signIn')} onPress={onSubmit} loading={loading} />
      <Button title={t('auth.noAccount')} variant="ghost" onPress={() => router.replace('/sign-up')} />
    </AuthShell>
  );
}
