import React, { useState } from 'react';
import { Alert } from 'react-native';
import { router } from 'expo-router';
import { AuthShell } from '@/src/components/AuthShell';
import { Button, TextField } from '@/src/components/ui';
import { useAuth } from '@/src/context/AuthContext';
import { useI18n } from '@/src/context/LanguageContext';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function SignUp() {
  const { t } = useI18n();
  const { signUp } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);

  async function onSubmit() {
    if (!name.trim() || !email.trim() || !password) return Alert.alert(t('auth.fillAll'));
    if (!EMAIL_RE.test(email.trim())) return Alert.alert(t('auth.invalidEmail'));
    if (password.length < 8) return Alert.alert(t('auth.passwordTooShort'));
    if (password !== confirm) return Alert.alert(t('auth.passwordsDontMatch'));

    setLoading(true);
    try {
      const signedIn = await signUp(email, password, name);
      if (!signedIn) {
        Alert.alert(t('auth.checkEmailTitle'), t('auth.checkEmailBody', { email: email.trim() }));
        router.replace('/sign-in');
      }
    } catch (e: any) {
      Alert.alert(t('common.error'), e?.message ?? t('common.errorBody'));
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthShell title={t('auth.signUpTitle')} subtitle={t('auth.signUpSubtitle')}>
      <TextField label={t('auth.displayName')} value={name} onChangeText={setName} maxLength={80} autoComplete="name" />
      <TextField
        label={t('auth.email')}
        value={email}
        onChangeText={setEmail}
        autoCapitalize="none"
        autoComplete="email"
        keyboardType="email-address"
        textContentType="emailAddress"
      />
      <TextField
        label={t('auth.password')}
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        autoComplete="new-password"
        textContentType="newPassword"
      />
      <TextField
        label={t('auth.confirmPassword')}
        value={confirm}
        onChangeText={setConfirm}
        secureTextEntry
        autoComplete="new-password"
        textContentType="newPassword"
        onSubmitEditing={onSubmit}
      />
      <Button title={t('auth.signUp')} onPress={onSubmit} loading={loading} />
      <Button title={t('auth.haveAccount')} variant="ghost" onPress={() => router.replace('/sign-in')} />
    </AuthShell>
  );
}
