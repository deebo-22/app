import React, { useEffect, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import type { PurchasesPackage } from 'react-native-purchases';
import { Screen } from '@/src/components/Screen';
import { Button, Loading } from '@/src/components/ui';
import { colors, radius, spacing } from '@/src/constants/theme';
import { useAuth, computeIsPro } from '@/src/context/AuthContext';
import { useI18n } from '@/src/context/LanguageContext';
import type { TKey } from '@/src/i18n/strings';
import { getPackages, isPurchasesConfigured, purchase, restorePurchases } from '@/src/services/subscriptions';
import { captureError } from '@/src/services/monitoring';

const FEATURES: TKey[] = ['paywall.f1', 'paywall.f2', 'paywall.f3', 'paywall.f4'];

export default function Paywall() {
  const { t } = useI18n();
  const { refreshProfile } = useAuth();
  const [packages, setPackages] = useState<PurchasesPackage[] | null>(null);
  const [selected, setSelected] = useState<PurchasesPackage | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!isPurchasesConfigured()) {
      setPackages([]);
      return;
    }
    getPackages()
      .then((p) => {
        setPackages(p);
        setSelected(p[0] ?? null);
      })
      .catch((e) => {
        captureError(e);
        setPackages([]);
      });
  }, []);

  /**
   * The store purchase succeeds on-device first; Pro is only granted once the
   * RevenueCat webhook updates our profiles row. Poll briefly for that.
   */
  async function waitForServerEntitlement() {
    for (let i = 0; i < 6; i++) {
      const p = await refreshProfile();
      if (computeIsPro(p)) return true;
      await new Promise((r) => setTimeout(r, 1500));
    }
    return false;
  }

  async function buy() {
    if (!selected) return;
    setBusy(true);
    try {
      await purchase(selected);
      const active = await waitForServerEntitlement();
      Alert.alert(active ? t('paywall.success') : t('paywall.pending'));
      router.back();
    } catch (e: any) {
      if (!e?.userCancelled) {
        captureError(e);
        Alert.alert(t('paywall.failed'));
      }
    } finally {
      setBusy(false);
    }
  }

  async function restore() {
    setBusy(true);
    try {
      await restorePurchases();
      await waitForServerEntitlement();
      Alert.alert(t('paywall.restored'));
    } catch (e) {
      captureError(e);
      Alert.alert(t('paywall.failed'));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen edges={['top', 'bottom']}>
      <View style={styles.close}>
        <Pressable onPress={() => router.back()} hitSlop={10} accessibilityRole="button" accessibilityLabel={t('common.cancel')}>
          <Feather name="x" size={26} color={colors.textMuted} />
        </Pressable>
      </View>
      <View style={styles.hero}>
        <View style={styles.crown}>
          <MaterialCommunityIcons name="crown-outline" size={34} color={colors.pro} />
        </View>
        <Text style={styles.title}>{t('paywall.title')}</Text>
        <Text style={styles.subtitle}>{t('paywall.subtitle')}</Text>
      </View>

      <View style={styles.features}>
        {FEATURES.map((k) => (
          <View key={k} style={styles.feature}>
            <View style={styles.check}>
              <Feather name="check" size={13} color={colors.primaryText} />
            </View>
            <Text style={styles.featureText}>{t(k)}</Text>
          </View>
        ))}
      </View>

      {packages == null ? (
        <Loading />
      ) : packages.length === 0 ? (
        <Text style={styles.unavailable}>{t('paywall.notAvailable')}</Text>
      ) : (
        <>
          {packages.map((p) => (
            <Pressable
              key={p.identifier}
              onPress={() => setSelected(p)}
              style={[styles.pkg, selected?.identifier === p.identifier && styles.pkgSelected]}
            >
              <View style={{ flex: 1 }}>
                <Text style={styles.pkgTitle}>{p.product.title}</Text>
                {p.product.description ? <Text style={styles.pkgDesc}>{p.product.description}</Text> : null}
              </View>
              <Text style={styles.pkgPrice}>{p.product.priceString}</Text>
            </Pressable>
          ))}
          <Button title={t('profile.startPro')} variant="pro" onPress={buy} loading={busy} style={{ marginTop: spacing.md }} />
          <Button title={t('paywall.restore')} variant="ghost" onPress={restore} disabled={busy} />
        </>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  close: { flexDirection: 'row', justifyContent: 'flex-end', paddingTop: spacing.md },
  hero: { alignItems: 'center', gap: spacing.sm, marginTop: spacing.md },
  crown: {
    width: 72,
    height: 72,
    borderRadius: 22,
    backgroundColor: colors.proSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: { fontSize: 28, fontWeight: '800', color: colors.text },
  subtitle: { fontSize: 14, color: colors.textMuted, textAlign: 'center' },
  features: {
    marginVertical: spacing.xxl,
    gap: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
  },
  feature: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  check: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  featureText: { flex: 1, fontSize: 14, color: colors.textBody },
  unavailable: { fontSize: 14, color: colors.textMuted, textAlign: 'center' },
  pkg: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 2,
    borderColor: colors.border,
    padding: spacing.lg,
    marginBottom: spacing.sm,
  },
  pkgSelected: { borderColor: colors.pro, backgroundColor: '#FBF9FF' },
  pkgTitle: { fontSize: 15, fontWeight: '700', color: colors.text },
  pkgDesc: { fontSize: 12, color: colors.textMuted, marginTop: 2 },
  pkgPrice: { fontSize: 16, fontWeight: '800', color: colors.text },
});
