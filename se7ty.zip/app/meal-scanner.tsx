import React, { useState } from 'react';
import { Alert, Image, StyleSheet, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';
import { Screen } from '@/src/components/Screen';
import { StackHeader } from '@/src/components/StackHeader';
import { ProGate } from '@/src/components/ProGate';
import { Button, Card, Chip } from '@/src/components/ui';
import { colors, radius, spacing } from '@/src/constants/theme';
import { useAuth } from '@/src/context/AuthContext';
import { useI18n } from '@/src/context/LanguageContext';
import { recognizeMeal, saveMealToDiary, type RecognitionResult } from '@/src/services/meals';
import { captureError } from '@/src/services/monitoring';
import type { DiaryMealType } from '@/src/types/database';

const MEAL_TYPES: DiaryMealType[] = ['breakfast', 'lunch', 'dinner', 'snack'];

export default function MealScanner() {
  const { t } = useI18n();
  const { isPro } = useAuth();

  // Defensive Pro check on the screen itself — reachable by deep link.
  if (!isPro) {
    return (
      <Screen>
        <StackHeader title={t('mealScan.title')} />
        <ProGate />
      </Screen>
    );
  }
  return <MealScannerPro />;
}

function MealScannerPro() {
  const { t } = useI18n();
  const { user } = useAuth();
  const [photo, setPhoto] = useState<string | null>(null);
  const [result, setResult] = useState<RecognitionResult | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [mealType, setMealType] = useState<DiaryMealType>('lunch');
  const [saving, setSaving] = useState(false);

  async function pick(fromCamera: boolean) {
    try {
      if (fromCamera) {
        const perm = await ImagePicker.requestCameraPermissionsAsync();
        if (!perm.granted) return Alert.alert(t('mealScan.permissionDenied'));
      }
      const opts: ImagePicker.ImagePickerOptions = { mediaTypes: ['images'], quality: 0.7, allowsEditing: true };
      const res = fromCamera
        ? await ImagePicker.launchCameraAsync(opts)
        : await ImagePicker.launchImageLibraryAsync(opts);
      if (!res.canceled && res.assets[0]) {
        setPhoto(res.assets[0].uri);
        setResult(null);
      }
    } catch (e) {
      captureError(e);
    }
  }

  async function analyze() {
    if (!photo) return;
    setAnalyzing(true);
    try {
      setResult(await recognizeMeal(photo));
    } catch (e) {
      captureError(e);
      Alert.alert(t('common.error'));
    } finally {
      setAnalyzing(false);
    }
  }

  async function save() {
    if (!user || !result) return;
    setSaving(true);
    try {
      await saveMealToDiary(user.id, result.items, mealType);
      Alert.alert(t('mealScan.saved'));
      router.back();
    } catch (e) {
      captureError(e);
      Alert.alert(t('common.error'));
    } finally {
      setSaving(false);
    }
  }

  const total = result?.items.reduce((s, i) => s + i.calories, 0) ?? 0;

  return (
    <Screen>
      <StackHeader title={t('mealScan.title')} />
      <Text style={styles.subtitle}>{t('mealScan.subtitle')}</Text>

      <View style={styles.photoBox}>
        {photo ? (
          <Image source={{ uri: photo }} style={StyleSheet.absoluteFill} resizeMode="cover" />
        ) : (
          <Feather name="camera" size={40} color="rgba(255,255,255,0.5)" />
        )}
      </View>

      <View style={styles.buttons}>
        <Button title={t('mealScan.takePhoto')} compact onPress={() => pick(true)} style={{ flex: 1 }} />
        <Button title={t('mealScan.choosePhoto')} compact variant="secondary" onPress={() => pick(false)} style={{ flex: 1 }} />
      </View>

      {photo && !result && (
        <Button
          title={analyzing ? t('mealScan.analyzing') : t('mealScan.analyze')}
          onPress={analyze}
          loading={analyzing}
          style={{ marginTop: spacing.md }}
        />
      )}

      {result && (
        <>
          {result.isMock && (
            <View style={styles.mock}>
              <Feather name="alert-triangle" size={14} color="#8A5A00" />
              <Text style={styles.mockText}>{t('mealScan.mock')}</Text>
            </View>
          )}
          <Card style={{ marginTop: spacing.md, paddingVertical: spacing.sm }}>
            {result.items.map((i, idx) => (
              <View key={idx} style={[styles.item, idx < result.items.length - 1 && styles.divider]}>
                <Text style={styles.itemName}>{i.food_name}</Text>
                <Text style={styles.itemKcal}>
                  {Math.round(i.calories)} {t('common.kcal')}
                </Text>
              </View>
            ))}
            <View style={[styles.item, styles.totalRow]}>
              <Text style={styles.totalLabel}>{t('mealScan.total')}</Text>
              <Text style={styles.totalLabel}>
                {Math.round(total)} {t('common.kcal')}
              </Text>
            </View>
          </Card>
          <Text style={styles.logAs}>{t('mealScan.logAs')}</Text>
          <View style={styles.chips}>
            {MEAL_TYPES.map((m) => (
              <Chip key={m} label={t(`meal.${m}`)} selected={m === mealType} onPress={() => setMealType(m)} />
            ))}
          </View>
          <Button title={t('mealScan.save')} onPress={save} loading={saving} style={{ marginTop: spacing.lg }} />
        </>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  subtitle: { fontSize: 13, color: colors.textMuted, textAlign: 'center', marginBottom: spacing.lg },
  photoBox: {
    height: 280,
    borderRadius: radius.xl,
    backgroundColor: colors.cameraBg,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttons: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.md },
  mock: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#FFF4E0',
    borderRadius: radius.sm,
    padding: spacing.md,
    marginTop: spacing.lg,
  },
  mockText: { flex: 1, fontSize: 12, color: '#8A5A00' },
  item: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: spacing.md },
  divider: { borderBottomWidth: 1, borderBottomColor: colors.divider },
  itemName: { fontSize: 15, color: colors.textBody, flex: 1 },
  itemKcal: { fontSize: 14, color: colors.textMuted },
  totalRow: { borderTopWidth: 1, borderTopColor: colors.border },
  totalLabel: { fontSize: 15, fontWeight: '800', color: colors.text },
  logAs: { fontSize: 13, fontWeight: '600', color: colors.textBody, marginTop: spacing.lg, marginBottom: spacing.sm },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
});
