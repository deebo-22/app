import React, { useEffect, useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useLocalSearchParams } from 'expo-router';
import { Screen } from '@/src/components/Screen';
import { StackHeader } from '@/src/components/StackHeader';
import { ProductRow } from '@/src/components/ProductRow';
import { Chip } from '@/src/components/ui';
import { colors, radius, spacing } from '@/src/constants/theme';
import { useI18n } from '@/src/context/LanguageContext';
import { searchProducts } from '@/src/services/products';
import { captureError } from '@/src/services/monitoring';
import type { ProductCategory, ProductDetail } from '@/src/types/database';

const CATEGORIES: ProductCategory[] = ['food', 'cosmetics', 'supplements'];

function isCategory(v: unknown): v is ProductCategory {
  return typeof v === 'string' && (CATEGORIES as string[]).includes(v);
}

export default function Search() {
  const { t } = useI18n();
  const params = useLocalSearchParams<{ category?: string }>();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<ProductCategory | undefined>(
    isCategory(params.category) ? params.category : undefined,
  );
  const [results, setResults] = useState<ProductDetail[]>([]);
  const [loading, setLoading] = useState(false);

  // Debounced search; ignores responses from superseded queries.
  useEffect(() => {
    let cancelled = false;
    if (!query.trim() && !category) {
      setResults([]);
      return;
    }
    setLoading(true);
    const timer = setTimeout(() => {
      searchProducts(query, category)
        .then((r) => !cancelled && setResults(r))
        .catch((e) => captureError(e))
        .finally(() => !cancelled && setLoading(false));
    }, 300);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [query, category]);

  const hasQuery = !!query.trim() || !!category;

  return (
    <Screen>
      <StackHeader />
      <View style={styles.search}>
        <Feather name="search" size={18} color={colors.textMuted} />
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder={t('home.searchPlaceholder')}
          placeholderTextColor={colors.textSubtle}
          autoFocus={!category}
          returnKeyType="search"
          style={styles.input}
          maxLength={60}
        />
        {loading && <ActivityIndicator size="small" color={colors.primary} />}
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips}>
        <Chip label={t('search.all')} selected={!category} onPress={() => setCategory(undefined)} />
        {CATEGORIES.map((c) => (
          <Chip key={c} label={t(`category.${c}`)} selected={category === c} onPress={() => setCategory(c)} />
        ))}
      </ScrollView>
      {hasQuery && !loading && results.length === 0 ? (
        <Text style={styles.empty}>{t('search.noResults')}</Text>
      ) : (
        results.map((p) => <ProductRow key={p.id} product={p} />)
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  search: {
    height: 50,
    borderRadius: radius.md,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
  },
  input: { flex: 1, fontSize: 15, color: colors.textBody },
  chips: { gap: spacing.sm, paddingVertical: spacing.lg },
  empty: { fontSize: 14, color: colors.textMuted, textAlign: 'center', marginTop: spacing.xxl },
});
