import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Screen } from '@/src/components/Screen';
import { StackHeader } from '@/src/components/StackHeader';
import { Card } from '@/src/components/ui';
import { colors, spacing } from '@/src/constants/theme';
import { useI18n } from '@/src/context/LanguageContext';
import type { TKey } from '@/src/i18n/strings';

const PARAGRAPHS: TKey[] = ['scoring.p1', 'scoring.p2', 'scoring.p3', 'scoring.p4'];
const LEGEND = [
  { key: 'verdict.excellent', range: '75–100', color: colors.judgment.excellent },
  { key: 'verdict.good', range: '50–74', color: colors.judgment.good },
  { key: 'verdict.poor', range: '25–49', color: colors.judgment.poor },
  { key: 'verdict.bad', range: '0–24', color: colors.judgment.bad },
] as const;

/** Transparency page for the scoring algorithm (linked from every product). */
export default function ScoringMethod() {
  const { t } = useI18n();
  return (
    <Screen edges={['top', 'bottom']}>
      <StackHeader title={t('scoring.title')} />
      <Card style={{ gap: spacing.md }}>
        {LEGEND.map((l) => (
          <View key={l.key} style={styles.legend}>
            <View style={[styles.dot, { backgroundColor: l.color }]} />
            <Text style={styles.legendLabel}>{t(l.key)}</Text>
            <Text style={styles.legendRange}>{l.range}</Text>
          </View>
        ))}
      </Card>
      <View style={{ gap: spacing.lg, marginTop: spacing.xl }}>
        {PARAGRAPHS.map((p) => (
          <Text key={p} style={styles.p}>
            {t(p)}
          </Text>
        ))}
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  legend: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  dot: { width: 14, height: 14, borderRadius: 7 },
  legendLabel: { flex: 1, fontSize: 15, fontWeight: '600', color: colors.text },
  legendRange: { fontSize: 14, color: colors.textMuted },
  p: { fontSize: 15, lineHeight: 23, color: colors.textBody },
});
